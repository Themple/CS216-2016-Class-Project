import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.util.List;
import java.util.ArrayList;
/**
 * Write a description of class Field here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Field extends JPanel
{
    private final int IMAGE_SIZE = 56; //players are going to be scaled down to IMAGE_SIZE by IMAGE_SIZE

    //sort of arbitrary numbers, just got them through guessing and checking
    private final Point FIRST_BASE_RUNNING = new Point(374, 171);
    private final Point SECOND_BASE_RUNNING = new Point(232, 149);
    private final Point THIRD_BASE_RUNNING = new Point(66, 173);
    private final Point FIRST_BASE_NOT_RUNNING = new Point(365, 165); //not running is position for fielder if needed
    private final Point SECOND_BASE_NOT_RUNNING = new Point(225, 140);
    private final Point THIRD_BASE_NOT_RUNNING = new Point(66, 160);
    private final Point HOME_PLATE_BATTING = new Point(250, 270);
    private final Point HOME_PLATE_NOT_BATTING = new Point(240, 270);

    private final Point MIDDLE_OUT_FIELD = new Point(232, 100);
    private final Point LEFT_OUT_FIELD = new Point(66, 120);
    private final Point RIGHT_OUT_FIELD = new Point(365, 120);

    private final int LEFT_FIELD_C = 0; //c for catch
    private final int LEFT_FIELD_NC = 3; //nc for did not catch
    private final int MIDDLE_FIELD_C = 1;
    private final int MIDDLE_FIELD_NC = 4;
    private final int RIGHT_FIELD_C = 2;
    private final int RIGHT_FIELD_NC = 5;

    private BufferedImage field, ball;
    private List<BufferedImage> redPlayers, bluePlayers;

    private JLabel fieldLabel, ballLabel;
    private List<JLabel> redPlayerLabels, bluePlayerLabels;

    private List<JLabel> redFielders, blueFielders;
    private List<JLabel> redRunners, blueRunners;
    private JLabel redBatter, blueBatter;

    private String[] imgNames = { "atBat", "catch", "didNotCatch", "running" };
    public Field(){
        init();
    }

    private void init(){
        /**
         * Setting the layout to null makes the panel use "absolute layout" which
         * lets the images be positioned anywhere
         */
        setLayout(null);

        redPlayers = new ArrayList<>();
        bluePlayers = new ArrayList<>();
        redPlayerLabels = new ArrayList<>();
        bluePlayerLabels = new ArrayList<>();

        initImages();

        initField();

        initPlayers();
    }

    /**
     * Adds an image to a JLabel "fieldLabel" which is used to display the field. 
     * The image is scaled down to 544 by 408. The bounds are set so it can be positioned
     * anywhere(the 0,0 is what does that) and the image is constrained to a size of
     * 544 by 408. If the image were bigger than that, it anything outside 544 by 408 would
     * just be cut off. Finally, the image is set to a location of 0,0 which is the top
     * left corner of the screen. 
     */
    private void initField(){
        fieldLabel = new JLabel(new ImageIcon(field.getScaledInstance(544, 408, Image.SCALE_SMOOTH)));
        fieldLabel.setBounds(0,0,544,408);
        fieldLabel.setLocation(0,0);
        add(fieldLabel);
    }

    /**
     * Sets the positions of the images and creates copies for images that are used
     * multiple times(fielders, players on bases).
     * 
     * The playerLabel arraylists are set up in a way that corresponds to the imgNames array.
     * If you do redPlayerLabels.get(0) then the image for a red player at bat will be returned.
     */
    private void initPlayers(){
        redFielders = new ArrayList<>();
        blueFielders = new ArrayList<>();

        /**
         * There are going to be 3 people in the outfield and they can have
         * two possible pictures: catch or did not catch. 0, 1, 2 of either
         * array will return the image for catch and 3, 4, 5 will return
         * did not catch.
         * 
         * I created 3 copies of each(one for each position in outfield) so they can all be
         * manipulated individually.
         */
        for(int i = 0; i < 6; i++){
            if(i < 3){
                redFielders.add(new JLabel(redPlayerLabels.get(1).getIcon()));
                blueFielders.add(new JLabel(bluePlayerLabels.get(1).getIcon()));
            }else{
                redFielders.add(new JLabel(redPlayerLabels.get(2).getIcon()));
                blueFielders.add(new JLabel(bluePlayerLabels.get(2).getIcon())); 
            }
        }

        /**
         * Setting the bounds seems to be the "magic" of creating the gui with images
         * that are on top of each other. Honestly, I'm not too sure why it is 
         * necessary, but images won't display if the bounds aren't set.
         */
        redFielders.forEach(label -> label.setBounds(0,0, IMAGE_SIZE, IMAGE_SIZE));
        blueFielders.forEach(label -> label.setBounds(0,0, IMAGE_SIZE, IMAGE_SIZE));
        //have to manually set the positions of the out fielders
        redFielders.get(LEFT_FIELD_C).setLocation(LEFT_OUT_FIELD);
        redFielders.get(MIDDLE_FIELD_C).setLocation(MIDDLE_OUT_FIELD);
        redFielders.get(RIGHT_FIELD_C).setLocation(RIGHT_OUT_FIELD);
        redFielders.get(LEFT_FIELD_NC).setLocation(LEFT_OUT_FIELD);
        redFielders.get(MIDDLE_FIELD_NC).setLocation(MIDDLE_OUT_FIELD);
        redFielders.get(RIGHT_FIELD_NC).setLocation(RIGHT_OUT_FIELD);

        blueFielders.get(LEFT_FIELD_C).setLocation(LEFT_OUT_FIELD);
        blueFielders.get(MIDDLE_FIELD_C).setLocation(MIDDLE_OUT_FIELD);
        blueFielders.get(RIGHT_FIELD_C).setLocation(RIGHT_OUT_FIELD);
        blueFielders.get(LEFT_FIELD_NC).setLocation(LEFT_OUT_FIELD);
        blueFielders.get(MIDDLE_FIELD_NC).setLocation(MIDDLE_OUT_FIELD);
        blueFielders.get(RIGHT_FIELD_NC).setLocation(RIGHT_OUT_FIELD);

        redFielders.forEach(label -> label.setVisible(false));
        blueFielders.forEach(label -> label.setVisible(false));

        redFielders.forEach(label -> fieldLabel.add(label));
        blueFielders.forEach(label -> fieldLabel.add(label));

        /** Fielders are done */

        //just doing the same thing as before for batters
        redBatter = new JLabel(redPlayerLabels.get(0).getIcon());
        blueBatter = new JLabel(bluePlayerLabels.get(0).getIcon());

        redBatter.setBounds(0,0, IMAGE_SIZE, IMAGE_SIZE);
        blueBatter.setBounds(0,0, IMAGE_SIZE, IMAGE_SIZE);

        redBatter.setLocation(HOME_PLATE_BATTING);
        blueBatter.setLocation(HOME_PLATE_BATTING);

        redBatter.setVisible(false);
        blueBatter.setVisible(false);

        redRunners = new ArrayList<>(); //there will be 4 runners
        blueRunners = new ArrayList<>();

        for(int i = 0; i < 4; i++){
            redRunners.add(new JLabel(redPlayerLabels.get(3).getIcon()));
            blueRunners.add(new JLabel(bluePlayerLabels.get(3).getIcon()));
        }

        redRunners.forEach(label -> label.setBounds(0,0, IMAGE_SIZE, IMAGE_SIZE));
        blueRunners.forEach(label -> label.setBounds(0,0, IMAGE_SIZE, IMAGE_SIZE));

        redRunners.forEach(label -> label.setLocation(HOME_PLATE_BATTING));
        blueRunners.forEach(label -> label.setLocation(HOME_PLATE_BATTING));

        //add everything to the fieldLabel so it can be displayed!
        redFielders.forEach(label -> fieldLabel.add(label));
        blueFielders.forEach(label -> fieldLabel.add(label));
        redRunners.forEach(label -> fieldLabel.add(label));
        blueRunners.forEach(label -> fieldLabel.add(label));
        fieldLabel.add(redBatter);
        fieldLabel.add(blueBatter);

    }

    /**
     * Creates all the images to be used during the play-through and creates a JLabel from them.
     */
    private void initImages(){
        try {
            field = loadImage("field.jpg");
            ball = loadImage("ball.png");
            for(int i = 0; i < 8; i++){
                if(i % 2 == 0){
                    redPlayers.add(loadImage(imgNames[i/2] + "Red.png"));
                    redPlayerLabels.add(new JLabel(new ImageIcon(redPlayers.get(i/2).getScaledInstance(IMAGE_SIZE, IMAGE_SIZE, Image.SCALE_SMOOTH))));
                }else{
                    bluePlayers.add(loadImage(imgNames[i/2] + "Blue.png"));
                    bluePlayerLabels.add(new JLabel(new ImageIcon(bluePlayers.get(i/2).getScaledInstance(IMAGE_SIZE, IMAGE_SIZE, Image.SCALE_SMOOTH))));
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * The runToX() methods simply do what they say. The for loops within them
     * make the player run in a diagonal line. The location the player is being
     * set to uses some numbers that were just determined through random choice, really.
     * They just give a nice output for positions.
     * 
     * The image of the player(JLabel runner) is taken as a parameter along
     * with the team of the player, team one being red and team two being blue and
     * also an int for the current base.
     * The runner will always be null if the call is coming from the UserInterface
     * class. If the runner is null, a runner sitting a home base will be up to run
     * if they are going to first base. Otherwise, it is determined if there is a player
     * at the current base and then either a player from home is used (if no player at
     * current base) or the current base player is used for running.
     * 
     * The fact that it is a nested loop with both loops going up to 10,000 seems
     * scary, but there is practically no visible delay of the actual game when these run
     * and it gives a nice, smooth animation for the players.
     * 
     * The runTo second, third, and home methods double check that a player is actually on 
     * what should be the "starting" base. This makes it easy to do something like move
     * a player from first to third. To do this, you would just call runToThird and the
     * rest of the work is handled by the code :)
     */
    public void runToFirst(JLabel runner, int team){
        if(runner == null) runner = getRunnerAtHome(team);
        runner.setVisible(true);
        for(int i = 0; i < 10000; i++){
            for(int j = 0; j < 10000; j++){
                if(i == j && i % 5 == 0) runner.setLocation((int)(HOME_PLATE_BATTING.getX()+(i/80)), (int)(HOME_PLATE_BATTING.getY()-(i/100)));
            }
        }

        runner.setLocation(FIRST_BASE_RUNNING);
    }

    public void runToSecond(JLabel runner, int team, int currBase){
        if(runner == null){
            //if there is a player at the starting base(currBase), get the player.
            //otherwise, get a new player from home.
            if(isPlayerAtBase(team, currBase)){
                runner = getPlayerAtBase(team, currBase);
            } else runner = getRunnerAtHome(team);
        }
        runner.setVisible(true);
        if(!areTheseEqual(runner.getLocation(), FIRST_BASE_RUNNING)) runToFirst(runner, team);

        for(int i = 0; i < 10000; i++){
            for(int j = 0; j < 10000; j++){
                if(i == j && i % 5 == 0){
                    runner.setLocation((int)(FIRST_BASE_RUNNING.getX()-(i/70)), (int)(FIRST_BASE_RUNNING.getY()-(i/450)));
                }
            }
        }

        runner.setLocation(SECOND_BASE_RUNNING);
    }

    public void runToThird(JLabel runner, int team, int currBase){
        if(runner == null){
            //if there is a player at the starting base(currBase), get the player.
            //otherwise, get a new player from home.
            if(isPlayerAtBase(team, currBase)){
                runner = getPlayerAtBase(team, currBase);
            } else runner = getRunnerAtHome(team);
        }
        runner.setVisible(true);
        if(!areTheseEqual(runner.getLocation(), SECOND_BASE_RUNNING)) runToSecond(runner, team, currBase);

        for(int i = 0; i < 10000; i++){
            for(int j = 0; j < 10000; j++){
                if(i == j && i % 5 == 0){
                    runner.setLocation((int)(SECOND_BASE_RUNNING.getX()-(i/60)), (int)(SECOND_BASE_RUNNING.getY()+(i/400)));
                }
            }
        }

        runner.setLocation(THIRD_BASE_RUNNING);
    }

    public void runToHome(JLabel runner, int team, int currBase){
        if(runner == null){
            //if there is a player at the starting base(currBase), get the player.
            //otherwise, get a new player from home.
            if(isPlayerAtBase(team, currBase)){
                runner = getPlayerAtBase(team, currBase);
            } else runner = getRunnerAtHome(team);
        }
        runner.setVisible(true);
        if(!areTheseEqual(runner.getLocation(), THIRD_BASE_RUNNING)) runToThird(runner, team, currBase);

        for(int i = 0; i < 10000; i++){
            for(int j = 0; j < 10000; j++){
                if(i == j && i % 5 == 0) runner.setLocation((int)(THIRD_BASE_RUNNING.getX()+(i/70)), (int)(THIRD_BASE_RUNNING.getY()+(i/100)));
            }
        }
        //just pause for a second so the player doesn't instantly vanish
        try{
            Thread.sleep(400);
        }catch(Exception e){
            e.printStackTrace();
        }
        runner.setVisible(false);
        runner.setLocation(HOME_PLATE_BATTING);
    }

    /**
     * Taking the team and base number, will return true or false if there
     * is a player on the given base. This is just so I know the following
     * method (getPlayerAtBase()) will never have to return null.
     */
    private boolean isPlayerAtBase(int team, int base){
        Point location = null;
        switch(base){
            case 1:
            location = FIRST_BASE_RUNNING;
            break;
            case 2:
            location = SECOND_BASE_RUNNING;
            break;
            case 3:
            location = THIRD_BASE_RUNNING;
            break;
        }
        if(team == 1){
            for(JLabel runner: redRunners){
                if(areTheseEqual(location, runner.getLocation())) return true;
            }
        }else{
            for(JLabel runner: blueRunners){
                if(areTheseEqual(location, runner.getLocation())) return true;
            } 
        }
        return false;
    }

    /**
     * Returns the label of a player at a given base.
     * The "return null" has to be there so it compiles, but it will never
     * be called because the method above (isPlayerAtBase()) will always be
     * called beforehand to ensure there is a player at the base.
     */
    private JLabel getPlayerAtBase(int team, int base){
        Point location = null;
        switch(base){
            case 1:
            location = FIRST_BASE_RUNNING;
            break;
            case 2:
            location = SECOND_BASE_RUNNING;
            break;
            case 3:
            location = THIRD_BASE_RUNNING;
            break;
        }
        if(team == 1){
            for(JLabel runner: redRunners){
                if(areTheseEqual(location, runner.getLocation())) return runner;
            }
        }
        else{
            for(JLabel runner: blueRunners){
                if(areTheseEqual(location, runner.getLocation())) return runner;
            }
        }

        return null; //this will never be reached
    }

    /**
     * Sets everything to not be visible and sets the location of the
     * runners to the home plate.
     */
    public void clearField(){
        redFielders.forEach(label -> label.setVisible(false));
        blueFielders.forEach(label -> label.setVisible(false));
        redRunners.forEach(label -> label.setVisible(false));
        blueRunners.forEach(label -> label.setVisible(false));

        redRunners.forEach(label -> label.setLocation(HOME_PLATE_BATTING));
        blueRunners.forEach(label -> label.setLocation(HOME_PLATE_BATTING));
        redBatter.setVisible(false);
        blueBatter.setVisible(false);
    }
    
    /**
     * Sets the batter of a specified team to be visible.
     */
    public void makeBatterVisible(int team){
        if(team == 1) redBatter.setVisible(true);
        else if(team == 2) blueBatter.setVisible(true);
    }

    /**
     * Returns the first player found that is at home base.
     * There will always be at least 1 player at home base.
     */
    private JLabel getRunnerAtHome(int team){
        if(team == 1){ //red team
            JLabel runnerOne = redRunners.get(0);
            JLabel runnerTwo = redRunners.get(1);
            JLabel runnerThree = redRunners.get(2);
            JLabel runnerFour = redRunners.get(3);
            if(areTheseEqual(runnerOne.getLocation(), HOME_PLATE_BATTING)) return runnerOne;
            else if(areTheseEqual(runnerTwo.getLocation(), HOME_PLATE_BATTING)) return runnerTwo;
            else if(areTheseEqual(runnerThree.getLocation(), HOME_PLATE_BATTING)) return runnerThree;
            else return runnerFour;
        }else{
            JLabel runnerOne = blueRunners.get(0);
            JLabel runnerTwo = blueRunners.get(1);
            JLabel runnerThree = blueRunners.get(2);
            JLabel runnerFour = blueRunners.get(3);
            if(areTheseEqual(runnerOne.getLocation(), HOME_PLATE_BATTING)) return runnerOne;
            else if(areTheseEqual(runnerTwo.getLocation(), HOME_PLATE_BATTING)) return runnerTwo;
            else if(areTheseEqual(runnerThree.getLocation(), HOME_PLATE_BATTING)) return runnerThree;
            else return runnerFour;
        }
    }

    /**
     * Compares two Points and returns true if they're equal or false otherwise. 
     */
    private boolean areTheseEqual(Point p1, Point p2){
        if(p1.getX() == p2.getX() && p1.getY() == p2.getY()) return true;
        return false;
    }

    /**
     * Loads an image
     */
    private BufferedImage loadImage(String fileName) throws Exception {
        return ImageIO.read(this.getClass().getResource("images/" + fileName));
    }
}
