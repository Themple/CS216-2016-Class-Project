
/**
 * This is the basic class that describes each player. 
 * It contains the general stats that all players, 
 * reguardless of position, have. It also contains the 
 * act method for batting. 
 */
public class Player implements Actor
{
    private String name; //The player's name.
    private double battingAverage;//Player's batting average
    private String position; //Position in the team.
    private String fieldPosition;//Player's position for when they are in the field
    private double catchingAverage;//Player's catching average
    private boolean inField;//Boolean for if the player is in the field or not
    private Clock clock;
    private Randomizer rand;
    private static int ballPosition=0;
    private Stat stat;
    private Team team;
    private int strikeCount;

    public Player(String name, String Fieldposition,double catchingAvg,double battingAvg,Clock c,Randomizer r)
    {
        this.name= name; 
        this.position=Fieldposition;
        fieldPosition=Fieldposition;
        battingAverage=battingAvg;
        catchingAverage=catchingAvg;
        inField=true;
        clock=c;
        rand=r;
    }

    public void setStat(Stat stat){
        this.stat = stat;
    }

    public void setTeam(Team team){
        this.team = team;
    }

    /**
     * Accessor Method for the name variable.
     */
    public String getName()
    {
        return name; 
    }

    /**
     * Accessor method for the position variable.
     */
    public String getPosition()
    {
        return position;
    }
    
    public int getStrikeCount(){
        return strikeCount;
    }

    /**
     * Mutator method for the position variable.
     */
    public void setPosition(String p)
    {
        position=p;
    }

    /**
     * Sets the player's position to the bench as if the player got out
     **/
    public void out()
    {
        position="bench";
    }

    /**
     * Changes the players position to either their field position or bench depending on if they are to be put in the field or not
     **/
    public void setInField(boolean a)
    {
        inField=a;
        if(inField)
        {
            position=fieldPosition;
        }
        else
        {
            position="bench";
        }
    }

    /**
     * Sets the player to be at bat
     **/
    public void atBat()
    {
        position="batting";
    }

    /**
     * Changes the player's position as if they are switching sides
     **/
    public void switchSides()
    {
        if(inField)
        {
            inField=false;
            position="bench";
        }
        else
        {
            inField=true;
            position=fieldPosition;
        }
    }

    /**
     * Sets the player's position to the bench
     **/
    public void bench()
    {
        position="bench";
    }

    /**
     * returns if the player is in the field or not
     **/
    public boolean isInField()
    {
        return inField;
    }

    public int getBallPosition()
    {
        return ballPosition;
    }

    /**
     * Makes the player act in a certain manner depending on their current position
     **/
    public void act() 
    {
        if(position.equals("batting"))
        {
            double chance=rand.randomize(100);
            int direction=rand.randomize(3);

            if(chance<=battingAverage*30)
            {
                if(chance<=2*battingAverage)
                {
                    //he hit a homerun
                    //System.out.print(name+" hit a homerun ");
                    if(direction==1)
                    {
                        //System.out.println("to left field");
                        stat.sendEventMessage(this,clock.getTick(),1,1);
                    }
                    else if(direction==2)
                    {
                        //System.out.println("to mid field");
                        stat.sendEventMessage(this,clock.getTick(),1,2);
                    }
                    else if(direction==3)
                    {
                        //System.out.println("to right field");
                        stat.sendEventMessage(this,clock.getTick(),1,3);
                    }
                    position="bench";
                }
                else if(chance<=10*battingAverage)
                {
                    //he hit a triple
                    //System.out.print(name+" hit a triple ");
                    if(direction==1)
                    {
                        //System.out.println("to left field");
                        stat.sendEventMessage(this,clock.getTick(),2,1);
                    }
                    else if(direction==2)
                    {
                        //System.out.println("to mid field");
                        stat.sendEventMessage(this,clock.getTick(),2,2);
                    }
                    else if(direction==3)
                    {
                        //System.out.println("to right field");
                        stat.sendEventMessage(this,clock.getTick(),2,3);
                    }
                    position="third";

                }
                else if(chance<=20*battingAverage)
                {
                    //he hit a double
                    //System.out.print(name+" hit a double ");
                    if(direction==1)
                    {
                        //System.out.println("to left field");
                        stat.sendEventMessage(this,clock.getTick(),3,1);
                    }
                    else if(direction==2)
                    {
                        //System.out.println("to mid field");
                        stat.sendEventMessage(this,clock.getTick(),3,2);
                    }
                    else if(direction==3)
                    {
                        //System.out.println("to right field");
                        stat.sendEventMessage(this,clock.getTick(),3,3);
                    }
                    position="second";

                }
                else
                {
                    //he hit a single
                    //System.out.print(name+ " hit a single ");
                    if(direction==1)
                    {
                        //System.out.println("to left field");
                        stat.sendEventMessage(this,clock.getTick(),4,1);
                    }
                    else if(direction==2)
                    {
                        //System.out.println("to mid field");
                        stat.sendEventMessage(this,clock.getTick(),4,2);
                    }
                    else if(direction==3)
                    {
                        //System.out.println("to right field");
                        stat.sendEventMessage(this,clock.getTick(),4,3);
                    }
                    position="first";
                    strikeCount=0;

                }
                ballPosition=direction;
            }
            else if(chance<battingAverage*30+battingAverage)
            {
                //he hit a foul
                if(strikeCount <2)
                {
                    strikeCount++;
                }
                else 
                {
                    strikeCount= strikeCount;
                }
                //System.out.println(name+ " hit a foul (Strike: "+ strikeCount+")");
                stat.sendEventMessage(this,clock.getTick(),0,0);
                if(strikeCount==3)
                {
                    strikeCount=0;
                    out();
                }

            }
            else
            {
                //he got a strike
                strikeCount++;
                //System.out.println(name+": strike " + strikeCount);
                stat.sendEventMessage(this,clock.getTick(),-1,0);
                if(strikeCount==3)
                {
                    strikeCount=0;
                    out();
                }

            }
        }
        else if(((position.equals("Left Field"))&&(ballPosition==1))||(position.equals("Mid Field")&&(ballPosition==2))||(position.equals("Right Field")&&(ballPosition==3)))
        {
            double chance=rand.randomize(100);
            if(chance<= catchingAverage*200) 
            {
                //catches ball, throw it to a given base.
                //System.out.println(name+" caught ball");
                stat.sendEventMessage(this,clock.getTick(),5,0);    
                ballPosition=4;
                strikeCount=0;
            }
            else
            {
                //didnt catch the ball
                //System.out.println(name+" doesn't catch the ball");
                stat.sendEventMessage(this,clock.getTick(),6,0);
                ballPosition=4;
            }
        }
        else if((position.equals("first"))||(position.equals("second"))||(position.equals("third")))
        {
                double chance=rand.randomize(100);
                if((!position.equals("first"))||(!position.equals("second"))||(!position.equals("third")))
                {}
                else if(chance<=70)
                {
                    //Player made it to the next base
                    if(position.equals("first"))
                    {
                        position="second";
                        stat.sendEventMessage(this,clock.getTick(),7,2);
                    }
                    else if(position.equals("second"))
                    {
                        position="third";
                        stat.sendEventMessage(this,clock.getTick(),7,3);
                    }
                    else if(position.equals("third"))
                    {
                        position="bench";
                        stat.sendEventMessage(this,clock.getTick(),8,0);
                        //send message for the player going to home base
                    }
                }
                else
                {
                    //System.out.println(name+" got out while running");
                    position="bench";
                    strikeCount=0;
                    stat.sendEventMessage(this,clock.getTick(),9,0);
                    //send message for getting out
                }
            
        }
    }

    /**
     * Returns the player's name and position in a string.
     */
    public String toString()
    {
        return name+": "+position;
    }
}
