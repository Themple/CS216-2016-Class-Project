import java.util.ArrayList;
/**
 * Team class will create and maintain the two teams that are playing. 
 * 
 * @author Josh Martine
 */
public class Team implements Actor
{
    private final int FIRST = 0, SECOND = 1, THIRD = 2;

    private ArrayList<Player> players;
    private ArrayList<Player> teamOne, teamTwo;
    private String teamOneName, teamTwoName;
    private boolean teamOneAtBat, teamTwoAtBat;
    private Clock clock;
    private Randomizer rand;
    private float inning;
    private int outs = 0;
    //private int teamOneScore = 0, teamTwoScore = 0;
    private Stat stat;

    public ArrayList<Player> playersOnBases;

    public Team(String teamOneName, String teamTwoName, Clock clock, Randomizer rand){
        this.teamOneName = teamOneName;
        this.teamTwoName = teamTwoName;
        this.clock = clock;
        this.rand = rand;
        players = new ArrayList<>();
        teamOne = new ArrayList<>();
        teamTwo = new ArrayList<>();
        inning = 1;

        playersOnBases = new ArrayList<>();
        playersOnBases.add(FIRST, null);
        playersOnBases.add(SECOND, null);
        playersOnBases.add(THIRD, null);

    }

    public String getTeamOneName()
    {
        return teamOneName;
    }

    public String getTeamTwoName()
    {
        return teamTwoName;
    }

    public void setStat(Stat stat){
        this.stat = stat;
    }

    public void setRand(Randomizer rand){
        this.rand = rand;
    }

    /**
     * Gives all Player objects an instance of Team
     */
    private void setPlayerTeams(){
        players.forEach(player -> {
                player.setTeam(this); 
                player.setStat(stat);
            });
        firstAtBat();
    }

    /**
     * determines the team that will bat first, sets the first player of the team to batting,
     * and sets the rest of the players to benched/in the field
     */
    private void firstAtBat(){
        if(rand.randomize(1)+1 == 2) teamOneAtBat = true;
        else teamTwoAtBat = true;

        for(int i = 0; i < teamOne.size(); i++){
            if(teamOneAtBat){
                teamOne.get(i).setPosition("bench");
                teamOne.get(i).setInField(false);
            }
            else{
                teamTwo.get(i).setPosition("bench");
                teamTwo.get(i).setInField(false);
            }
        }

        if(teamOneAtBat){
            teamOne.get(0).setPosition("batting");
        } else {
            teamTwo.get(0).setPosition("batting");
        }

        //System.out.println("Now batting: " + (teamOneAtBat ? teamOneName : teamTwoName));
        //System.out.println(teamOneName + " score: " + teamOneScore);
        //System.out.println(teamTwoName + " score: " + teamTwoScore);
    }

    /**
     * called from controller. adds players to the teams.
     */
    public void setTeams(ArrayList<Player> teams){
        players = teams;
        for(int i = 0; i < teams.size() / 2; i++){
            teamOne.add(teams.get(i));
        }

        for(int i = teams.size() / 2; i < teams.size(); i++){
            teamTwo.add(teams.get(i));
        }   
        setPlayerTeams();
    }

    /**
     *  Changes who is at bat, increases the inning count, and makes players switch sides;
     */    
    public void changeTeamAtBat(){
        teamOneAtBat = !teamOneAtBat;
        teamTwoAtBat = !teamTwoAtBat;
        inning += 0.5f;
        if(inning % 1 == 0) stat.sendEventMessage(null, clock.getTick(), 11, 0);
        else stat.sendEventMessage(null, clock.getTick(), 10, 0);
        players.forEach(p -> p.switchSides());
        for(int i = 0; i < playersOnBases.size(); i++){
            playersOnBases.set(i, null);
        }
        if(teamOneAtBat) teamOne.get(0).setPosition("batting");
        else teamTwo.get(0).setPosition("batting");
    }

    /**
     * Returns the inning
     */
    public float getInning(){
        return inning;
    }

    /**
     * Returns the player who is currently at bat.
     */
    public Player getCurrentBatter(){
        return teamOneAtBat ? teamOne.get(0) : teamTwo.get(0);
    }

    /**
     * Removes the player who was batting and adds them back to the end of the team list.
     * Then sets the new first player to batting. 
     */
    public void changeBatter(){
        if(teamOneAtBat){
            teamOne.add(teamOne.remove(0));
            teamOne.get(0).setPosition("batting");
        } else {
            teamTwo.add(teamTwo.remove(0));
            teamTwo.get(0).setPosition("batting");
        }
    }

    public String toString(){
        String retStr = "";
        retStr += teamOneName + ": ";
        for(int i = 0; i < teamOne.size(); i++){
            retStr += teamOne.get(i) + " ";
        }
        retStr += "\n" + teamTwoName + ": ";
        for(int i = 0; i < teamTwo.size(); i++){
            retStr += teamTwo.get(i) + " ";
        }
        return retStr;
    }

    public void manageBases(Player batter, int caseNum){
        if(caseNum == 1) { //homerun
            if(teamOneAtBat){
                for(Player p: playersOnBases){
                    if(p != null){
                        stat.sendEventMessage(p, clock.getTick(), 8, 1);
                    }
                }
                stat.sendEventMessage(batter, clock.getTick(), 8, 1);
            } else if(teamTwoAtBat){
                for(Player p : playersOnBases){
                    if(p != null){
                        stat.sendEventMessage(p, clock.getTick(), 8, 2);
                    }
                }
                stat.sendEventMessage(batter, clock.getTick(), 8, 2);
            }
            playersOnBases.forEach(p -> p = null);
            changeBatter();
        } else if(caseNum == 2) { //triple
            if(teamOneAtBat){
                for(Player p: playersOnBases){
                    if(p != null){
                        stat.sendEventMessage(p, clock.getTick(), 8, 1);
                    }
                }
            } else if(teamTwoAtBat){
                for(Player p : playersOnBases){
                    if(p != null){
                        stat.sendEventMessage(p, clock.getTick(), 8, 2);
                    }
                }
            }
            playersOnBases.forEach(p -> p = null);
            playersOnBases.add(THIRD, batter);
            changeBatter();
        } else if(caseNum == 3) { //double
            if(playersOnBases.get(THIRD) != null){
                stat.sendEventMessage(playersOnBases.get(THIRD), clock.getTick(), 8, teamOneAtBat ? 1 : 2);
                playersOnBases.add(THIRD, null);
            }
            if(playersOnBases.get(SECOND) != null){
                stat.sendEventMessage(playersOnBases.get(SECOND), clock.getTick(), 8, teamOneAtBat ? 1 : 2);
                playersOnBases.add(SECOND, batter);
            }
            if(playersOnBases.get(FIRST) != null){
                playersOnBases.add(THIRD, playersOnBases.remove(FIRST)); // .remove() returns what was removed
                playersOnBases.add(FIRST, null);
            }
            playersOnBases.add(SECOND, batter);
            changeBatter();
        } else if(caseNum == 4) { //single
            if(playersOnBases.get(THIRD) != null){
                stat.sendEventMessage(playersOnBases.get(THIRD), clock.getTick(), 8, teamOneAtBat ? 1 : 2);
                playersOnBases.add(THIRD, null);
            }
            if(playersOnBases.get(SECOND) != null){
                playersOnBases.add(THIRD, playersOnBases.remove(SECOND));
                playersOnBases.add(SECOND, null);
            }
            if(playersOnBases.get(FIRST) != null){
                playersOnBases.add(THIRD, playersOnBases.remove(FIRST));
                playersOnBases.add(FIRST, null);
            }
            playersOnBases.add(FIRST, batter);
            changeBatter();
        }

    }

    public void act(){
        Player currBatter = getCurrentBatter(); //the person at bat will act
        currBatter.act();
        EventMessage msg = stat.getMostRecentMessage(); //get the most recent message, will say what happened (strike, hit...)
        if(msg.getMessageCode() != -1 && msg.getMessageCode() != 1) {
            if(teamOneAtBat){
                for(int i = 0; i < teamTwo.size(); i++){
                    teamTwo.get(i).act();
                    if(stat.getMostRecentMessage().getMessageCode() == 5){
                        currBatter.bench();
                        break;
                    }
                }
            } else {
                for(int i = 0; i < teamOne.size(); i++){
                    teamOne.get(i).act();
                    if(stat.getMostRecentMessage().getMessageCode() == 5){
                        currBatter.bench();
                        break;
                    }
                }
            }
        }
        //the batters position is set to bench if they hit a homerun so need to make sure their hit is processed
        if(!currBatter.getPosition().equals("bench") || msg.getMessageCode() == 1){
            manageBases(currBatter, msg.getMessageCode());
        }else if(currBatter.getStrikeCount() == 3 || currBatter.getPosition().equals("bench")){
            outs++;
            stat.sendEventMessage(currBatter, clock.getTick(), 9, 0);
            changeBatter();
        }
        if(outs > 2){
            changeTeamAtBat();
            outs = 0;
            //System.out.println("-----Inning " + inning + "-----");
            //System.out.println("Now batting: " + (teamOneAtBat ? teamOneName : teamTwoName));
            //System.out.println(teamOneName + " score: " + teamOneScore);
            //System.out.println(teamTwoName + " score: " + teamTwoScore);
        }
    }
}
