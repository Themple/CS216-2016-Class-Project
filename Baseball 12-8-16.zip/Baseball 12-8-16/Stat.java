import java.util.*;
import java.util.Iterator;
/**
 * For now, This is going to recieve the event messages 
 * sent in by each specific class. 
 * Stat will also display each message. 
 * 
 * -Ryan Priore, building dummy.
 */
public class Stat //extends EventMessage
{
    protected ArrayList <EventMessage> m;
    private HashMap<Integer, String> codeText = new HashMap<>();
    private Team team;
    private Clock clock;
    private int readTracker;
    /**
     * Sets the list of command codes in the hash map.
     * Initializes the instance variables.
     */
    public Stat( Team t, Clock c)
    {
        m = new ArrayList<>();
        team = t;
        clock = c;
        //list of codes
        codeText.put(-1,"strike");
        codeText.put(0,"foul");
        codeText.put(1,"homerun");
        codeText.put(2,"triple"); 
        codeText.put(3,"double");
        codeText.put(4,"single");
        codeText.put(5,"caught the ball");
        codeText.put(6,"failed to catch the ball");
        codeText.put(7,"ran to next base"); //additional code 2 means to second 3 means third
        codeText.put(8,"ran to home"); //additional code 1 means for team one 2 means team two
        codeText.put(9,"got out");
        codeText.put(10, "\nTeam change\n");
        codeText.put(11, "\nInning change\n");
        readTracker = 0;
    }

    public EventMessage getMostRecentMessage(){
        return m.get(m.size()-1);
    }

    public EventMessage getNextUnreadMessage() throws Exception{
        if(hasNext()){
            EventMessage temp = m.get(readTracker);
            readTracker++;
            return temp;
        } else throw new Exception("Out of messages");
    }

    public String msgToString(EventMessage m){
        String retStr = "";
        if(m.getPlayer() != null) retStr = m.getPlayer().getName(); //player is set to null when team/inning switch
        int mCode = m.getMessageCode();
        if(mCode < 1){
            retStr += ": ";
        }else if(mCode >= 1 && mCode < 5){
            retStr += " hit a ";
        }else if(mCode >= 5 && mCode < 10){
            retStr += " ";
        }
        retStr += codeText.get(mCode);
        return retStr;
    }

    public boolean hasNext(){
        return readTracker != m.size()-1;
    }

    /**
     * This Method will find a given key in the map, and return the value if found.
     * If the value isnt there, or is null, the proper exception will be thrown.
     */
    public String getCodeText(int key) throws Exception
    {
        if(codeText.containsKey(key)) {
            return codeText.get(key);
        } else throw new Exception("Code not found: " +key);
    }

    public String mostRecentMessage(){
        return m.get(m.size()-1).toString() + "\n";
    }

    /**
     * Adds the event messages into the array list. 
     */
    public void sendEventMessage(Player p, int time, int messageCode, int additional)
    {
        m.add(new EventMessage(p, time, messageCode, additional));
    }

    /**
     * This is TEST code to print events. 
     * It will change when every class can send a message. 
     * For now, this should work for players. 
     */
    public void printEventMessage() 
    {
        for(EventMessage x: m) 
        {
            System.out.println(x);
        }
    }
}
