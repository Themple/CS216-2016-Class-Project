
/**
 * Write a description of class Batter here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Batter extends Player
{
    // instance variables - replace the example below with your own
    private double battingAverage;

    /**
     * Constructor for objects of class Batter
     */
    public Batter(String name,String team, double b)
    {
        super(name,team);
        battingAverage=b;
    }
    public double getBattingAverage()
    {
        return battingAverage;
    }
    public void act()
    {
        double chance=Math.random();
        if(chance<=battingAverage)
        {
            if(chance<=.1*battingAverage)
            {
                //he hit a homerun
                System.out.println("player hit a homerun");
            }
            else if(chance<=.3*battingAverage)
            {
                //he hit a triple
                System.out.println("player hit a triple");
            }
            else if(chance<=.5*battingAverage)
            {
                //he hit a double
                System.out.println("player hit a double");
            }
            else
            {
                //he hit a single
                System.out.println("player hit a single");
            }
            super.act();
        }
        else if(chance<battingAverage*.1+battingAverage)
        {
            //he hit a foul
        }
        else
        {
            //he got a strike
        }
        
    }
}
