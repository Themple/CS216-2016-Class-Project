
/**
 * This is the basic class that describes each player. 
 * It contains the general stats that all players, 
 * reguardless of position, have. It also contains the 
 * act method for batting. 
 */
public class Player implements Actor
{
    private String name; //The player's name.
    private String team; //The team that the player belongs to.
    private String position; //Position in the team.
    
    public Player(String name, String team)
    {
        this.name= name; 
        this.team= team; 
        position="bench";
    }
    public String getName() //Returns the Player's name.
    {
        return name; 
    }
    public String getTeam() //Returns the Player's team name.
    {
        return team; 
    }
    public String getPosition() //Returns the Player's Position (or Role) in the team.
    {
        return position;
    }
    public void setPosition(String p)
    {
        position=p;
    }
    public void act() //Makes the player run the bases
    {
        //int basesGained get how good the batter hit the ball
        System.out.println("player ran x bases");
    }
}
