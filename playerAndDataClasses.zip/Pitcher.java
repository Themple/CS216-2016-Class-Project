
/**
 * This class describes everything that the pitcher does. 
 * It contains the stats of a pitcher and the act method 
 * that tells the pitcher when to pitch. 
 * This class has general variables (such as "name") 
 * that are inherited from the parent class "Player".
 */
public class Pitcher extends Player
{
    private double pitchingAverage; //Total # of hits allowed by pitcher / by total # of oppnent at-bats
    private double walkHitAverage; // average amount of walks and hits by a pitcher. 
    public Pitcher(String name, String team ,double pitchingAverage, double walkHitAverage)
    {
        super(name,team);
        this.pitchingAverage= pitchingAverage;  
        this.walkHitAverage= walkHitAverage; 
    }

    public String getName() 
    {
        return super.getName();
    }

    public String getTeam() 
    {
        return super.getTeam();
    }

    public double getPitchingAverage()
    {
        return pitchingAverage;
    }

    public double getWalkHitAverage() 
    {
        return walkHitAverage;
    }

    public void act() //Override act method that tells the pitcher to pitch.
    {
        double chance= Math.random();
        if(chance<= pitchingAverage)
        {
            int whichball= (int)Math.random()*4;
            if(whichball==0)
            {
                //throw fast ball
            }
            else if(whichball==1) 
            {
                //throw curve ball
            }
            else if(whichball==2)
            {
                // throw a "ball"
            }
        }
        System.out.println("player pitched");
    }
}
