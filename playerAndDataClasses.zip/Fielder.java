
/**
 * Write a description of class Fielder here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Fielder extends Player
{
    private int putOuts;
    private double catchingChance;
    public Fielder(String name, String team ,int putOuts, double catchingChance)
    {
        super(name,team);
        this.putOuts=putOuts;
        this.catchingChance= catchingChance;
    } 
    public String getName() 
    {
        return super.getName();
    }
    public String getTeam() 
    {
        return super.getTeam();
    } 
    public int getPutOuts()
    {
        return putOuts;
    }
    public double getCatchingChance()
    {
        return catchingChance;
    }
    public void act()//method to control a player based on their position in the field
    {
        double chance= Math.random();
        if(chance<= catchingChance)
        {
            //catches ball, throw it to a given base.
             System.out.println("caught ball");
        }
        else  
        {
            //didnt catch the ball
             System.out.println("dropped the ball");
        }
    }
}
