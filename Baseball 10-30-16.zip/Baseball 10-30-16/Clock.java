
/**
 * A custom clock that initiates a "tick" 
 * It is the time variable for the simulation.
 */
public class Clock
{
    private int tick;
    private boolean playing;

    /**
     * Constructor for objects of class Clock
     */
    public Clock()
    {
        tick=1;
        playing=false;
    }

    /**
     * Starts the game and resets the clock.
     */
    public void startGame()
    {
        playing=true;
        tick=1;
    }

    /**
     * Initiates the "tick"; 
     * Controls the time for the simulation.
     */
    public void tick()
    {
        tick++;
    }

    /**
     * Accessor Method for the time variable.
     */
    public int getTick()
    {
        return tick;
    }
}
