import java.util.ArrayList;
import java.util.Random;
import java.util.*;
/**
 * Write a description of class Controller here.
 * 
 * @author (Dimitri Terenik) 
 * @version (10/18/16)
 */
public class Controller
{

    ArrayList<Player> plays;
    private Clock clock;
    private ArrayList<Player> players;
    private Stat stat;
    private Randomizer rand;
    private Team team;
    
    public  Controller(){
        plays = new ArrayList<>();
        players=new ArrayList<>();
        clock = new Clock();
        stat = new Stat(team,clock);
        rand = new Randomizer();
        team = new Team("red","blue", clock, rand);
        buildPlayer();
        
        team.setTeams(players);
        play();
    }
    
    public void buildPlayer() 
    {
        players.add(new Player("Alfredo Aceves","Pitcher" , .511, .200,clock,rand,stat)); //1 
        players.add(new Player("Brandon Bantz","Catcher" , .571, .245,clock,rand,stat)); //2 
        players.add(new Player("Miguel Cabrera","First Base" , .641, .316,clock,rand,stat)); //3 
        players.add(new Player("Dustin Pedroia","Secound Base" , .671, .318,clock,rand,stat)); //4 
        players.add(new Player("David Adams","Third Base" , .441, .193,clock,rand,stat)); //5 
        players.add(new Player("Nick Ahmed","Short Stop" , .481, .218,clock,rand,stat)); //6 
        players.add(new Player("Abraham Almonte","Left Field" , .661, .264,clock,rand,stat)); //7 
        players.add(new Player("Mike Trout","Center Field" , .811, .315,clock,rand,stat)); //8 
        players.add(new Player("Pedro Valdes","Right Field" , .731, .247,clock,rand,stat)); //9 

        players.add(new Player("Mike Adams","Pitcher" , .341, .175,clock,rand,stat)); //10 
        players.add(new Player("Carson Blair","Catcher" , .441, .250,clock,rand,stat)); //11 
        players.add(new Player("Brandon Allen","First Base", .681 , .100,clock,rand,stat)); //12 
        players.add(new Player("Jose Pirela","Second Base" , .581, .154,clock,rand,stat)); //13 
        players.add(new Player("Kris Bryant","Third Base" , .681, .292,clock,rand,stat)); //14
        players.add(new Player("Gavin Cecchini","Short Stop" , .345, .333,clock,rand,stat)); //15
        players.add(new Player("Tyler Colvin","Left Field" , .654, .233,clock,rand,stat)); //16 
        players.add(new Player("Dalton Pompey","Center Field" , .475, .222,clock,rand,stat)); //17 
        players.add(new Player("Adam Walker","Right Field" , .657, .243,clock,rand,stat)); //18 
    }
    
    public void play(){
        while(team.getInning() < 9){
            team.act();
        }
        clock.tick();
    }
}
