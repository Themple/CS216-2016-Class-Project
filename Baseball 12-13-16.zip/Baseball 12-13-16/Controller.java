import java.util.ArrayList;
import java.util.Random;
import java.util.*;
/**
 * Write a description of class Controller here.
 * 
 * @author (Dimitri Terenik) 
 * @version (10/18/16)
 */
public class Controller
{
    public static int teamOneScore, teamTwoScore;

    private ArrayList<Player> players;
    private Clock clock;
    private Stat stat;
    private Randomizer rand;
    private Team team;
    private UserInterface ui;

    private boolean teamOneAtBat = false, teamTwoAtBat = false;
    private float inningCount = 1.0f;
    public Controller(){
        teamOneScore = 0;
        teamTwoScore = 0;

        players = new ArrayList<>();
        clock = new Clock();
        rand = new Randomizer();
        team = new Team("red","blue", clock, rand);
        stat = new Stat(team,clock);
        buildPlayer();
        team.setStat(stat);
        team.setTeams(players);
        if(team.getFirstAtBat() == 1) teamOneAtBat = true;
        else teamTwoAtBat = true;
        ui= new UserInterface(stat, team);
        play();
    }

    /**
     * Information and stats for all Specific Players in the game.
     * Used to build the two teams.
     */
    public void buildPlayer() 
    {
        players.add(new Player("Alfredo Aceves","Pitcher" , .200, .511,clock,rand)); //1 
        players.add(new Player("Brandon Bantz","Catcher" , .245, .571,clock,rand)); //2 
        players.add(new Player("Miguel Cabrera","First Base" , .316, .641,clock,rand)); //3 
        players.add(new Player("Dustin Pedroia","Secound Base" , .318, .671,clock,rand)); //4 
        players.add(new Player("David Adams","Third Base" , .193, .441,clock,rand)); //5 
        players.add(new Player("Nick Ahmed","Short Stop" , .218, .481,clock,rand)); //6 
        players.add(new Player("Abraham Almonte","Left Field" , .264, .661,clock,rand)); //7 
        players.add(new Player("Mike Trout","Center Field" , .315, .811,clock,rand)); //8 
        players.add(new Player("Pedro Valdes","Right Field" , .247, .731,clock,rand)); //9 

        players.add(new Player("Mike Adams","Pitcher" , .175, .341,clock,rand)); //10 
        players.add(new Player("Carson Blair","Catcher" , .250, .441,clock,rand)); //11 
        players.add(new Player("Brandon Allen","First Base" , .100, .681,clock,rand)); //12 
        players.add(new Player("Jose Pirela","Second Base" , .154, .581,clock,rand)); //13 
        players.add(new Player("Kris Bryant","Third Base" , .292, .681,clock,rand)); //14
        players.add(new Player("Gavin Cecchini","Short Stop" , .333, .345,clock,rand)); //15
        players.add(new Player("Tyler Colvin","Left Field" , .233, .654,clock,rand)); //16 
        players.add(new Player("Dalton Pompey","Center Field" , .222, .475,clock,rand)); //17 
        players.add(new Player("Adam Walker","Right Field" , .243, .657,clock,rand)); //18 
    }
    int j = 0;
    public void play()
    {
        while(team.getInning() < 10){
            team.act();
            //System.out.println(team.getInning());
            clock.tick();
        }
        ui.clearField();
        if(teamOneAtBat) ui.makeBatterVisible(1);
        else ui.makeBatterVisible(2);
        while(stat.hasNext()){
            try{
                EventMessage nextUnreadMsg = stat.getNextUnreadMessage();
                String toBeAdded = useMessage(nextUnreadMsg);
                ui.outputText += toBeAdded +(toBeAdded.equals("") ?  "" : "\n");
                ui.update();
            } catch(Exception e){
                e.printStackTrace();
            }
            try{
                Thread.sleep(400 / (long)( ui.getPlaySpeed())); //slows everything down a bit
            } catch(Exception e){
                System.out.println("oops");
            }
        }
        ui.clearField();

        ui.outputText += "\n\n\nEnd of game\n";
        ui.outputText += "Final scores: Team Red: " + teamOneScore + " -- Team Blue: " + teamTwoScore;
        ui.update();
    }

    private String useMessage(EventMessage nextUnreadMsg){
        String toBeAdded = stat.msgToString(nextUnreadMsg);
        if(toBeAdded.contains("ran home")){
            ui.runPlayer(teamOneAtBat ? 1 : 2, 4);
            if(nextUnreadMsg.getAdditional() == 1) teamOneScore++;
            else teamTwoScore++;
        }else if(toBeAdded.contains("ran to") && !toBeAdded.contains("ran to home")){
            if(toBeAdded.contains("first")) ui.runPlayer(teamOneAtBat ? 1 : 2, 1);
            else if(toBeAdded.contains("second")) ui.runPlayer(teamOneAtBat ? 1 : 2, 2);
            else if(toBeAdded.contains("third")) ui.runPlayer(teamOneAtBat ? 1 : 2, 3);
            toBeAdded = "";
            if(teamOneAtBat) ui.makeBatterVisible(1);
            else ui.makeBatterVisible(2);
        }else if(toBeAdded.contains("Inning change")){
            inningCount += 1f;
            toBeAdded += " - Inning " + inningCount + "\n";
            ui.clearField();
            switchSides();
            if(teamOneAtBat) ui.makeBatterVisible(1);
            else ui.makeBatterVisible(2);
        }else if(toBeAdded.contains("Team change")){
            ui.clearField();
            switchSides();
            if(teamOneAtBat) ui.makeBatterVisible(1);
            else ui.makeBatterVisible(2);
        }
        return toBeAdded;
    }

    private void switchSides(){
        teamOneAtBat = !teamOneAtBat;
        teamTwoAtBat = !teamTwoAtBat;
    }
}
