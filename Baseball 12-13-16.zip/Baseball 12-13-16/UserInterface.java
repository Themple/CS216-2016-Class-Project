import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * Write a description of class UserInteface here.
 * 
 * @author Josh Martine
 * @version (a version number or a date)
 */
public class UserInterface extends JFrame
{
    /**
     * 
     * Nothing in this class is permanent. Everything is subject to change based on what everyone deems necessary.
     *
     */
    private JTextArea output;
    private JTextArea outputScore;
    public String outputScoreText = "";
    public String outputText = "";
    private JLabel image;
    private JPanel controlPanel;

    private int speed = 1; //makes the game go faster/slower
    private boolean paused;

    private Stat stat;
    private Team team;

    private Field field;

    public UserInterface(Stat stat, Team team){
        super("CCC Baseball Simulator");
        this.stat = stat;
        this.team = team;
        init();
    }

    public void init(){
        //makes the window 850x500 (i think)
        setPreferredSize(new Dimension(850,500));
        Container contentPane = getContentPane();
        contentPane.setLayout(new BorderLayout());

        JPanel Score = new JPanel();
        Score.setLayout(new BorderLayout());

        //creates a text area (with a width of 25) to output info like strike, hit, out, etc and puts it on the west (left) side
        output = new JTextArea(23,25);
        output.setEditable(false);
        JScrollPane scrollableOutput = new JScrollPane(output);
        Score.add(scrollableOutput, BorderLayout.NORTH);
        outputScore = new JTextArea(1,15);
        outputScore.setEditable(false);
        Score.add(outputScore,BorderLayout.SOUTH);
        contentPane.add(Score,BorderLayout.EAST);

        //createField();
        //contentPane.add(fieldUI, BorderLayout.CENTER);
        image = new JLabel();
        ImageIcon img = new ImageIcon("images/field.jpg");
        //scales down the image to 506x382(around 1/3 orig size) and sets it to the new (smaller) image
        img = new ImageIcon(img.getImage().getScaledInstance(544, 408,  Image.SCALE_SMOOTH));
        image.setIcon(img);
        //contentPane.add(image, BorderLayout.CENTER);

        field = new Field();
        contentPane.add(field, BorderLayout.CENTER);

        //creates a new panel for buttons
        controlPanel = new JPanel();
        createButtons();
        controlPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
        contentPane.add(controlPanel, BorderLayout.SOUTH);

        pack();
        setVisible(true);
    }

    public void runPlayer(int team, int base){
        switch(base){
            case 1:
            field.runToFirst(null, team);
            break;
            case 2:
            field.runToSecond(null, team, 1);
            break;
            case 3:
            field.runToThird(null, team, 2);
            break;
            case 4:
            field.runToHome(null, team, 3);
            break;
        }
    }
    
    public void makeBatterVisible(int team){
        field.makeBatterVisible(team);
    }
    
    public void clearField(){
        field.clearField();
    }

    /**
     * Creates the buttons for the control panel
     */
    public void createButtons(){
        JButton resumeButton = new JButton("Resume");
        JButton pauseButton = new JButton("Pause");
        JButton clearButton = new JButton("Clear");
        JButton newGameButton = new JButton("New Game");

        //adds listeners for the buttons that detect when clicked. makes them do something when clicked
        resumeButton.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e)
                {
                    outputText += "Start pressed\n";
                    paused = false;
                    update();
                }
            });

        pauseButton.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e)
                {
                    outputText += "Pause pressed\n";
                    paused = true;
                    update();
                }
            });

        clearButton.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e)
                {
                    outputText = "";
                    outputText += "Clear pressed\n";
                    update();
                }
            });

        newGameButton.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    dispose();
                    new Controller();
                }

            });

        //creates a new panel specifically for speed. makes things a bit easier
        JPanel speedPanel = new JPanel();
        speedPanel.setLayout(new BorderLayout());
        JLabel timeSpeed = new JLabel("Current speed: " + speed);
        JButton timeSpeedInc = new JButton("Increase speed by 1");
        JButton timeSpeedDec = new JButton("Decrease speed by 1");
        timeSpeedInc.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e)
                {
                    speed++;
                    timeSpeed.setText("Current speed: " + speed);
                    //outputText += "Time Inc pressed\n";
                    update();
                }
            });

        timeSpeedDec.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    if(speed > 1) speed--;
                    timeSpeed.setText("Current speed: " + speed);
                    //outputText += "Time Dec pressed\n";
                    update();
                }
            });

        speedPanel.add(timeSpeedInc, BorderLayout.WEST);
        speedPanel.add(timeSpeed, BorderLayout.CENTER);
        speedPanel.add(timeSpeedDec, BorderLayout.EAST);

        //controlPanel.add(resumeButton);
        //controlPanel.add(pauseButton);
        controlPanel.add(speedPanel);
        controlPanel.add(clearButton);
        //controlPanel.add(newGameButton);
    }

    /**
     * updates the "output" with whatever text is in outputText
     */
    public void update(){
        output.setText(outputText);
        outputScoreText = "Team Red:" + Controller.teamOneScore +"\nTeam Blue:" + Controller.teamTwoScore;
        outputScore.setText(outputScoreText);
        output.setCaretPosition(output.getDocument().getLength());
    }

    /**
     * Returns the current speed multiplier
     */
    public int getPlaySpeed(){
        return speed;
    }

    /**
     * Returns the current state of gameplay; paused or not.
     */
    public boolean getGamePaused(){
        return paused;
    }

}
