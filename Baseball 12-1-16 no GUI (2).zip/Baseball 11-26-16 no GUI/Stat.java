import java.util.*;
import java.util.Iterator;
/**
 * For now, This is going to recieve the event messages 
 * sent in by each specific class. 
 * Stat will also display each message. 
 * 
 * -Ryan Priore, building dummy.
 */
public class Stat //extends EventMessage
{
    protected ArrayList <EventMessage> m;
    private HashMap<Integer, String> codeText = new HashMap<>();
    Team team;
    Clock clock;
    private int messageCode; 
    private int additional;
    /**
     * Sets the list of command codes in the hash map.
     * Initializes the instance variables.
     */
    public Stat( Team t, Clock c)
    {
        m = new ArrayList<>();
        team = t;
        clock = c;
        //list of codes
        codeText.put(-1,"Strike!");
        codeText.put(0,"Foul");
        codeText.put(1,"Homerun");
        codeText.put(2,"Triple"); 
        codeText.put(3,"Double");
        codeText.put(4,"Single");
        codeText.put(5,"Ball was caught");
        codeText.put(6,"Failed to catch ball");
        codeText.put(7,"Run to next base"); //additional code 2 means to second 3 means third
        codeText.put(8,"Ran to home");
        codeText.put(9,"Player got out");
        codeText.put(10, "Team change");
        codeText.put(11, "Inning change");
    }
    
    public EventMessage getMostRecentMessage(){
        return m.get(m.size()-1);
    }
    
    public void s(){
        System.out.println("a");
    }

    /**
     * This Method willfind a given key in the map, and return the value if found.
     * If the value isnt there, or is null, the proper exception will be thrown.
     */
    public String getCodeText(int key) throws Exception
    {
        if(codeText.containsKey(key)) {
            return codeText.get(key);
        } else throw new Exception("Code not found: " +key);
    }

    /**
     * Adds the event messages into the array list. 
     */
    public void sendEventMessage(Player p, int time, int messageCode, int additional)
    {
        m.add(new EventMessage(p, time, messageCode, additional));
    }

    /**
     * This is TEST code to print events. 
     * It will change when every class can send a message. 
     * For now, this should work for players. 
     */
    public void printEventMessage() 
    {
        for(EventMessage x: m) 
        {
            System.out.println(x);
        }
    }
}
