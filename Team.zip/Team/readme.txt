There is a team that do essentially the same thing, except one version uses a hash map while the other uses an array list. 

this is no where near final, i will be making a lot of changes once the player class is designed

don't mind the test/tester classes.. they were just for testing as you could guess. the controller class should work fine for testing any methods. i also made a player class for both just for testing purposes.