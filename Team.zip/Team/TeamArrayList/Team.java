import java.util.ArrayList;
/**
 * Write a description of class Team here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Team
{
    private ArrayList<Player> team;
    boolean atBat;
    
    public Team(ArrayList<Player> team){
        this.team = team;
        atBat = false;
    }
    
    public ArrayList<Player> getTeam(){
        return team;
    }
    
    public void changeAtBat(){
        atBat = !atBat;
    }
    
    public Player getPlayer(String playerPos){
        Player p = null;
        for(int i = 0; i < team.size(); i++){
            if(team.get(i).getPos().equals(playerPos)){
                return team.get(i);
            } else p = null;
        }
        return p;
    }
    
    public String getPlayerPos(Player p){
        for(int i = 0; i < team.size(); i++){
            if(team.get(i).equals(p)) return team.get(i).getPos();
        }
        return "player not found";
    }
    
    public String toString(){
        String retStr = "";
        for(int i = 0; i < team.size(); i++){
            retStr += team.get(i) + " ";
        }
        return retStr;
    }
}
