
/**
 * Write a description of class Player here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Player implements Actor
{
    String text, pos;
    public Player(String tex, String pos){
        text = tex;
        pos = pos;
    }
    
    public void act(){
        
    }
    
    public String toString(){
        return text;
    }
    
    public String getPos(){
        return pos; //text is pos just for example
    }
}

