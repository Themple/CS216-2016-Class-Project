
/**
 * Write a description of interface Actor here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface Actor
{
    public void act();
}
