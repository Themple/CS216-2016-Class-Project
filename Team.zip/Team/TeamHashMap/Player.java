
/**
 * Write a description of class Player here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Player implements Actor
{
    String text;
    public Player(String tex){
        text = tex;
    }
    
    public void act(){
        
    }
    
    public String toString(){
        return text;
    }
}

