import java.util.HashMap;
import java.util.Map;
/**
 * Write a description of class Team here.
 * 
 * @author Josh Martine
 * @version (a version number or a date)
 */
public class Team
{
    private HashMap<String, Player> team;
    private boolean atBat;

    public Team(HashMap<String, Player> playerList){
        team = playerList;
        atBat = false;
    }

    public HashMap<String, Player> getTeam(){
        return team;
    }

    public void changeAtBat(){
        atBat = !atBat;
    }

    public Player getPlayer(String pos){
        return team.get(pos);
    }

    public String getPlayerPos(Player player){
        String retStr = "";
        if(team.containsValue(player)){
            for (Map.Entry<String, Player> entry : team.entrySet()) {
                if (entry.getValue().equals(player)) {
                    retStr = entry.getKey();
                }
            }
        }
        else retStr = "not found";
        return retStr;
    }

    public String toString(){
        String retStr = "";
        for (Map.Entry<String,Player> entry : team.entrySet()) {
            String key = entry.getKey();
            Player value = entry.getValue();
            retStr += ("Player: " + value + " --- Pos: " + key) + "\n";
        }
        return retStr;
    }
}
