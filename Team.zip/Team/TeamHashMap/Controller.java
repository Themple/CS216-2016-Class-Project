import java.util.ArrayList;
import java.util.Random;
import java.util.HashMap;
import java.util.List;
/**
 * Write a description of class Controller here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Controller
{
    Team teamOne, teamTwo;

    public Controller(){
        HashMap<String, Player> players = new HashMap<>();
        //String could be players position
        players.put("pitcher",new Player("one"));
        players.put("catcher",new Player("two"));
        players.put("first",new Player("three"));
        players.put("second",new Player("four"));
        players.put("third",new Player("five"));
        players.put("short",new Player("six"));
        generateTeams(players);
        
        System.out.println(teamOne.getPlayerPos(players.get("catcher")));
        System.out.println(teamOne);
    }

    public void generateTeams(HashMap<String, Player> players){
        Random rand = new Random();
        HashMap<String, Player> temp = new HashMap<>(); //this will be used to store the second team 
        List<String> keys = new ArrayList<String>(players.keySet()); //creates an arraylist of the keys in the map, aka "ONE", "TWO"...
        List<Player> values = new ArrayList<Player>(players.values()); //creates an arraylist of the values in the map, player one, player two etc
        for(int i = 0; i <= players.size() / 2.0; i++){ 
            int randInt = rand.nextInt(players.size());
            String tempName = keys.get(randInt);
            Player tempPlayer = values.get(randInt);
            keys.remove(randInt); //no duplicate key/value can be picked
            values.remove(randInt);

            temp.put(tempName, tempPlayer); //add the random player to the temporary map
            players.remove(tempName); //remove the player from the current map, no duplicates
        }

        teamOne = new Team(players);
        teamTwo = new Team(temp);
    }
   
}
