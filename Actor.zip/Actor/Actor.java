
/**
 * Write a description of class Actor here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Actor
{
    pubic interface Actor{
        public void act();
        
    }
    
    
}

