import java.util.ArrayList;
/**
 * Team class will create and maintain the two teams that are playing. 
 * 
 * @author Josh Martine
 */
public class Team implements Actor
{
    private ArrayList<Player> players;
    private ArrayList<Player> teamOne, teamTwo;
    private String teamOneName, teamTwoName;
    private boolean teamOneAtBat, teamTwoAtBat;
    private Clock clock;
    private Randomizer rand;
    private float inning;
    private int strikes = 0;
    private int outs = 0;
    private int teamOneScore=0, teamTwoScore=0 ;
    private Stat stat;

    public Team(String teamOneName, String teamTwoName, Clock clock, Randomizer rand){
        this.teamOneName = teamOneName;
        this.teamTwoName = teamTwoName;
        this.clock = clock;
        this.rand = rand;
        players = new ArrayList<>();
        teamOne = new ArrayList<>();
        teamTwo = new ArrayList<>();
        //teamOneScore= 0; 
        //teamTwoScore=0;
        inning = 1;
    }
    
    public String getTeamOneName()
    {
        return teamOneName;
    }
    public String getTeamTwoName()
    {
        return teamTwoName;
    }
    
    public void setTeamOneScore()
    {
        teamOneScore= teamOneScore++;
    }
    public void setTeamTwoScore()
    {
        teamTwoScore= teamTwoScore++;
    }
    
    public int getTeamOneScore()
    {
        return teamOneScore;
    }
    public int getTeamTwoScore()
    {
        return teamTwoScore;
    }

    public void setStat(Stat stat){
        //System.out.println(stat); <-- is causing the hashcode printout at the top of the simulation. f-Ryan
        this.stat = stat;
    }

    /**
     * Gives all Player objects an instance of Team
     */
    private void setPlayerTeams(){
        for(int i = 0; i < players.size(); i++){
            players.get(i).setTeam(this);
            players.get(i).setStat(stat);
        }
        firstAtBat();
    }

    /**
     * determines the team that will bat first, sets the first player of the team to batting,
     * and sets the rest of the players to benched/in the field
     */
    private void firstAtBat(){
        if(rand.randomize(1)+1 == 2) teamOneAtBat = true;
        else teamTwoAtBat = true;

        for(int i = 0; i < teamOne.size(); i++){
            if(teamOneAtBat){
                teamOne.get(i).setPosition("bench");
                teamOne.get(i).setInField(false);
            }
            else{
                teamTwo.get(i).setPosition("bench");
                teamTwo.get(i).setInField(false);
            }
        }

        if(teamOneAtBat){
            teamOne.get(0).setPosition("batting");
        } else {
            teamTwo.get(0).setPosition("batting");
        }

        System.out.println("Now batting: " + (teamOneAtBat ? teamOneName : teamTwoName));
        System.out.println(teamOneName + " score: " + teamOneScore);
        System.out.println(teamTwoName + " score: " + teamTwoScore);
    }

    /**
     * called from controller. adds players to the teams.
     */
    public void setTeams(ArrayList<Player> teams){
        players = teams;
        for(int i = 0; i < teams.size() / 2; i++){
            teamOne.add(teams.get(i));
        }

        for(int i = teams.size() / 2; i < teams.size(); i++){
            teamTwo.add(teams.get(i));
        }   
        setPlayerTeams();
    }

    /**
     * returns an arraylist of players in the specified team. if the team is invalid, throws an exception rather
     * than returning null
     */
    public ArrayList<Player> getTeam(String teamName){
        if(teamName.equals(teamOneName)) return teamOne;
        else if(teamName.equals(teamTwoName)) return teamTwo;
        return null;
    }

    /**
     * Returns a player at a given position. Throws PNFE if player isn't found.
     */
    public Player getPlayer(String playerPos) throws PlayerNotFoundException {
        for(int i = 0; i < players.size(); i++){
            if(teamOne.get(i).getPosition().equals(playerPos)){
                return teamOne.get(i);
            } else if(teamTwo.get(i).getPosition().equals(playerPos)){
                return teamTwo.get(i);
            }
        }

        throw new PlayerNotFoundException("Player not found at " + playerPos);
    }

    /**
     * Returns a player with a given name. Throws PNFE if player isn't found.
     */
    public Player getPlayerByName(String playerName) throws PlayerNotFoundException {

        for(int i = 0; i < players.size(); i++){
            if(teamOne.get(i).getName().equals(playerName)){
                return teamOne.get(i);
            } else if(teamTwo.get(i).getName().equals(playerName)){
                return teamTwo.get(i);
            }
        }
        throw new PlayerNotFoundException("Player not found: " + playerName);
    }

    /**
     *  Changes who is at bat, increases the inning count, and makes players switch sides;
     */    
    public void changeAtBat(){
        teamOneAtBat = !teamOneAtBat;
        teamTwoAtBat = !teamTwoAtBat;
        inning += 0.5f;
        for(Player player : players){
            player.switchSides();
        }
        if(teamOneAtBat) teamOne.get(0).setPosition("batting");
        else teamTwo.get(0).setPosition("batting");
    }

    /**
     * Returns the inning
     */
    public float getInning(){
        return inning;
    }

    /**
     * Returns the player who is currently at bat.
     */
    public Player getCurrentBatter(){
        return teamOneAtBat ? teamOne.get(0) : teamTwo.get(0);
    }

    /**
     * Removes the player who was batting and adds them back to the end of the team list.
     * Then sets the new first player to batting. 
     */
    public void changeBatter(){
        if(teamOneAtBat){
            teamOne.add(teamOne.remove(0));
            teamOne.get(0).setPosition("batting");
        } else {
            teamTwo.add(teamTwo.remove(0));
            teamTwo.get(0).setPosition("batting");
        }

        strikes= 0;
    }

    public String toString(){
        String retStr = "";
        retStr += teamOneName + ": ";
        for(int i = 0; i < teamOne.size(); i++){
            retStr += teamOne.get(i) + " ";
        }
        retStr += "\n" + teamTwoName + ": ";
        for(int i = 0; i < teamTwo.size(); i++){
            retStr += teamTwo.get(i) + " ";
        }
        return retStr;
    }

    //private int strikes = 0;
    //private int outs = 0;
    //private int teamOneScore = 0, teamTwoScore = 0;

    public void act(){
        // if(teamOneAtBat)
        // {
        //    for(Player p:teamOne)
        //    {
        //        if(p!=getCurrentBatter())
        //            p.act();
        //    }
        //}
        getCurrentBatter().act(); //the person at bat will act
        System.out.println(stat.getMostRecentMessage());
        EventMessage msg = stat.getMostRecentMessage(); //get the most recent message, will say what happened (strike, hit...)
        switch(msg.getMessageCode()){
            case -1: //strike
            strikes++;
            break;
            case 0: //foul
            if(strikes < 2) strikes++;
            break;
            case 1: //homerun
            if(teamOneAtBat) 
            {
                teamOneScore++;
                System.out.println(getCurrentBatter().getName() +" scored! Score= "+ teamOneScore);
                changeBatter();
            }
            else {teamTwoScore++;
                  System.out.println(getCurrentBatter().getName() +" scored! Score= "+ teamTwoScore);
                  changeBatter();
            }

            break;
            case 2: //triple
            changeBatter();
            break;
            case 3://double
            changeBatter();
            case 4://single
            changeBatter();
        }

        if(strikes > 2){
            outs++;
            strikes = 0;
            changeBatter();
            System.out.println("player out -----");
        }
        if(outs > 2){
            changeAtBat();
            outs = 0;
            System.out.println("Now batting: " + (teamOneAtBat ? teamOneName : teamTwoName));
            System.out.println(teamOneName + " score: " + teamOneScore);
            System.out.println(teamTwoName + " score: " + teamTwoScore);
        }
    }
}
