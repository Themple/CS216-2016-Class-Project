import java.util.Random;
/**this class will create random numbers from 1 to a designated number**/
public class Randomizer
{
    private Random rgen;
    public Randomizer()
    {
       rgen = new Random();
    }
    
    public int randomize(int x)
    {
        return rgen.nextInt(x)+1;
    }
    
}
