import java.util.ArrayList;
import java.util.Random;
/**
 * Team class will create and maintain the two teams that are playing. 
 * 
 * @author Josh Martine
 */
public class Team
{
    private ArrayList<Player> players;
    private ArrayList<Player> teamOne, teamTwo;
    private String teamOneName, teamTwoName;
    private boolean teamOneAtBat, teamTwoAtBat;

    public Team(ArrayList<Player> players, String teamOneName, String teamTwoName){
        this.players = players;
        this.teamOneName = teamOneName;
        this.teamTwoName = teamTwoName;
        teamOne = new ArrayList<>();
        teamTwo = new ArrayList<>();
        teamOneAtBat = false; //should be randomly decided
        teamTwoAtBat = false; //by a "coin flip" or something
    }

    //not sure if we want to split teams in this class or just have them handed to this class
    /*
     * public Team(ArrayList<Player> teamOne, ArrayList<Player> teamTwo, String teamOneName, String teamTwoName){
     *  this.teamOne = teamOne;
     *  this.teamTwo = teamTwo;
     *  this.teamOneName = teamOneName;
     *  this.teamTwoName = teamTwoName;
     *  teamOneAtBat = false;
     *  teamTwoAtBat = false;
     * }
     */

    /**
     * returns an arraylist of players in the specified team. if the team is invalid, throws an exception rather
     * than returning null
     */
    public ArrayList<Player> getTeam(String teamName){
        if(teamName.equals(teamOneName)) return teamOne;
        else if(teamName.equals(teamTwoName)) return teamTwo;
        return null;
    }

    public ArrayList<Player> getTeam(int teamNumber){
        if(teamNumber == 1) return teamOne;
        else if(teamNumber == 2) return teamTwo;
        return null;
    }

    /**
     * Returns a player at a given position.
     */

    public Player getPlayer(String playerPos) throws PlayerNotFoundException {
        for(int i = 0; i < teamOne.size(); i++){
            if(teamOne.get(i).getPosition().equals(playerPos)){
                return teamOne.get(i);
            }
        }

        for(int i = 0; i < teamTwo.size(); i++){
            if(teamTwo.get(i).getPosition().equals(playerPos)){
                return teamTwo.get(i);
            }
        }

        throw new PlayerNotFoundException("Player not found at " + playerPos);
    }

    public Player getPlayerByName(String playerName) throws PlayerNotFoundException{

        for(int i = 0; i < teamOne.size(); i++){
            if(teamOne.get(i).getName().equals(playerName)){
                return teamOne.get(i);
            }
        }

        for(int i = 0; i < teamTwo.size(); i++){
            if(teamTwo.get(i).getName().equals(playerName)){
                return teamTwo.get(i);
            }
        }
        throw new PlayerNotFoundException("Player not found: " + playerName);
    }

    /**
     * returns the position of a player. could throw exception if the player position can't be found.
     */

    public String getPlayerPos(Player p) {
        for(int i = 0; i < teamOne.size(); i++){
            if(teamOne.get(i).equals(p)){
                return teamOne.get(i).getPosition();
            }
        }

        for(int i = 0; i < teamTwo.size(); i++){
            if(teamTwo.get(i).equals(p)){
                return teamTwo.get(i).getPosition();

            } 
        }
        return "no position";
    }

    public void changeAtBat(){
        teamOneAtBat = !teamOneAtBat;
        teamTwoAtBat = !teamTwoAtBat;
    }

    public String toString(){
        String retStr = "";
        retStr += teamOneName + ": ";
        for(int i = 0; i < teamOne.size(); i++){
            retStr += teamOne.get(i) + " ";
        }
        retStr += ", " + teamTwoName + ": ";
        for(int i = 0; i < teamTwo.size(); i++){
            retStr += teamTwo.get(i) + " ";
        }
        return retStr;
    }
}
