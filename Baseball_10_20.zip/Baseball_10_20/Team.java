import java.util.ArrayList;
import java.util.Random;
/**
 * Team class will create and maintain the two teams that are playing. 
 * 
 * @author Josh Martine
 */
public class Team
{
    private ArrayList<Player> players; //contains all players
    private ArrayList<Player> teamOne, teamTwo;
    private String teamOneName, teamTwoName;
    private boolean teamOneAtBat, teamTwoAtBat;

    public Team(ArrayList<Player> players, String teamOneName, String teamTwoName){
        this.players = players;
        this.teamOneName = teamOneName;
        this.teamTwoName = teamTwoName;
        teamOne = new ArrayList<>();
        teamTwo = new ArrayList<>();
        generateTeams(); //temporary
        teamOneAtBat = false; //should be randomly decided
        teamTwoAtBat = false; //by a "coin flip" or something
    }

    /**
     * temporary
     * 
     */

    public void generateTeams(){
        for(int i = 0; i < players.size() / 2.0; i++){ // randomly assigns players from "players" arraylist to
            Random rand = new Random();                // team one. then, removes them from the "players" arraylist
            int randInt = rand.nextInt(players.size());// to prevent duplicates
            teamOne.add(players.get(randInt));
            players.remove(randInt);
        }
        for(int i = 0; i < players.size(); i++){ // half of the "players" arraylist is already gone, so just
            teamTwo.add(players.get(i));         // assign the rest to team two 
        }

        players.clear(); // "players" arraylist shouldn't be needed any more
    }

    /**
     * returns an arraylist of players in the specified team. if the team is invalid, throws an exception rather
     * than returning null
     */
    public ArrayList<Player> getTeam(String teamName){
        if(teamName.equals(teamOneName)) return teamOne;
        else if(teamName.equals(teamTwoName)) return teamTwo;
        return null;
    }

    public ArrayList<Player> getTeam(int teamNumber){
        if(teamNumber == 1) return teamOne;
        else if(teamNumber == 2) return teamTwo;
        return null;
    }

    /**
     * Returns a player at a given position. will throw PlayerNotFoundException if player isnt found, rather than
     * returning null
     */
    
    public Player getPlayer(String playerPos) {
        boolean found = false;
        for(int i = 0; i < teamOne.size(); i++){
            if(teamOne.get(i).getPosition().equals(playerPos)){
                found = true;
                return teamOne.get(i);
            }
        }

        if(!found){
            for(int i = 0; i < teamTwo.size(); i++){
                if(teamTwo.get(i).getPosition().equals(playerPos)){
                    found = true;
                    return teamTwo.get(i);
                }
            }
        }

        return null;
    }

    /**
     * returns the position of a player. could throw exception if the player can't be found.
     */
    
    public String getPlayerPos(Player p) {
        boolean found = false;
        for(int i = 0; i < teamOne.size(); i++){
            if(teamOne.get(i).equals(p)){
                found = true;
                return teamOne.get(i).getPosition();
            }
        }

        if(!found){
            for(int i = 0; i < teamTwo.size(); i++){
                if(teamTwo.get(i).equals(p)){
                    found = true;
                    return teamTwo.get(i).getPosition();
                }
            } 
        }
        return "player not found";
    }
    
    public void changeAtBat(){
        teamOneAtBat = !teamOneAtBat;
        teamTwoAtBat = !teamTwoAtBat;
    }

    public String toString(){
        String retStr = "";
        retStr += teamOneName + ": ";
        for(int i = 0; i < teamOne.size(); i++){
            retStr += teamOne.get(i) + " ";
        }
        retStr += ", " + teamTwoName + ": ";
        for(int i = 0; i < teamTwo.size(); i++){
            retStr += teamTwo.get(i) + " ";
        }
        return retStr;
    }
}
