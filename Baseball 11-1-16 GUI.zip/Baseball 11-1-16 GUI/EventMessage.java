import java.util.ArrayList;
/**
 *Creates an event message for a specific player
 *And puts it in the EventMessage array list to 
 *be stored and eventually called by stat.
 */
public class EventMessage
{
    private Player p;
    private int time;
    private int messageCode;
    private int additional;
    protected ArrayList <EventMessage> m;

    public EventMessage (Player p, int time, int messageCode, int additional)
    {
        m = new ArrayList<>();
        this.p = p;
        this.time = time;
        this.messageCode = messageCode;
        this.additional = additional;
    }

    public void addEvent( Player p, int time, int messageCode, int additional)
    {
        m.add(new EventMessage( p, time, messageCode, additional));
    }

    public String toString() 
    {
        return "Player: "+p+" time: "+time+" messageCode: "+messageCode+" additional: "+additional;
    }
}

    
