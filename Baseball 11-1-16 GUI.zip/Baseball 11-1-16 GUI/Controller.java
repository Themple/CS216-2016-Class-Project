import java.util.ArrayList;
import java.util.Random;
import java.util.*;
/**
 * Write a description of class Controller here.
 * 
 * @author (Dimitri Terenik) 
 * @version (10/18/16)
 */
public class Controller
{

    ArrayList<Player> players;
    private Clock clock;
    private Stat stat;
    private Randomizer rand;
    private Team team;
    private UserInterface ui;
    private boolean paused; 
    public  Controller(){
        players = new ArrayList<>();
        clock = new Clock();
        rand = new Randomizer();
        team = new Team("red","blue", clock, rand);
        stat = new Stat(team,clock);
        buildPlayer();
        team.setTeams(players);

        ui = new UserInterface(stat);

        play();
    }

    /**
     * Information and stats for all Specific Players in the game.
     * Used to build the two teams.
     */
    public void buildPlayer() 
    {
        players.add(new Player("Alfredo Aceves","Pitcher" , .200, .511,clock,rand,stat)); //1 
        players.add(new Player("Brandon Bantz","Catcher" , .245, .571,clock,rand,stat)); //2 
        players.add(new Player("Miguel Cabrera","First Base" , .316, .641,clock,rand,stat)); //3 
        players.add(new Player("Dustin Pedroia","Secound Base" , .318, .671,clock,rand,stat)); //4 
        players.add(new Player("David Adams","Third Base" , .193, .441,clock,rand,stat)); //5 
        players.add(new Player("Nick Ahmed","Short Stop" , .218, .481,clock,rand,stat)); //6 
        players.add(new Player("Abraham Almonte","Left Field" , .264, .661,clock,rand,stat)); //7 
        players.add(new Player("Mike Trout","Center Field" , .315, .811,clock,rand,stat)); //8 
        players.add(new Player("Pedro Valdes","Right Field" , .247, .731,clock,rand,stat)); //9 

        players.add(new Player("Mike Adams","Pitcher" , .175, .341,clock,rand,stat)); //10 
        players.add(new Player("Carson Blair","Catcher" , .250, .441,clock,rand,stat)); //11 
        players.add(new Player("Brandon Allen","First Base" , .100, .681,clock,rand,stat)); //12 
        players.add(new Player("Jose Pirela","Second Base" , .154, .581,clock,rand,stat)); //13 
        players.add(new Player("Kris Bryant","Third Base" , .292, .681,clock,rand,stat)); //14
        players.add(new Player("Gavin Cecchini","Short Stop" , .333, .345,clock,rand,stat)); //15
        players.add(new Player("Tyler Colvin","Left Field" , .233, .654,clock,rand,stat)); //16 
        players.add(new Player("Dalton Pompey","Center Field" , .222, .475,clock,rand,stat)); //17 
        players.add(new Player("Adam Walker","Right Field" , .243, .657,clock,rand,stat)); //18 
    }

    public void play()
    {
        while(team.getInning() < 9){
            paused = ui.getGamePaused();
            System.out.println(paused); // for some reason the resume doesn't work unless this is here
            if(!paused){
                team.act();
                ui.update();
                ui.outputText += stat.mostRecentMessage();
                try{
                    Thread.sleep(1000 / (long)( ui.getPlaySpeed())); //slows everything down a bit
                } catch(Exception e){
                    System.out.println("oops");
                }
            }
            clock.tick();
        }
    }
}
