
public class PlayerNotFoundException extends Exception
{

    public PlayerNotFoundException()
    {
        super("Player not found!");
    }
    
    public PlayerNotFoundException(String error)
    {
        super("Player not found: " + error);
    }
}