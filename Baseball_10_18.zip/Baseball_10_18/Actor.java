
/**
 * Write a description of class Actor here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

    public interface Actor
    {
        public void act();
        
    }
    
    

