import java.util.ArrayList;
import java.util.Random;
/**
 * Write a description of class Controller here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Controller
{
    ArrayList<Player> plays;
    Team t, t2;
    Clock clock = new Clock();
    public void play(){
        for(int j = 0; j<=500;j++){
            //team 1 maybe second for second team.
            for (Player p: plays){
                p.act();
            }
            clock.tick();  
        }
    }
}
