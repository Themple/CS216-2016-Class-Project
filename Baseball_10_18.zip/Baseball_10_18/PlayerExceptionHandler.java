import java.util.Scanner;
public class PlayerExceptionHandler
{
    public static void main()
    {
        
        try
        {
            if(onTeam(Player.getName()))
            {
                System.out.println("player is on team ___.");
            }
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
    }

    public static boolean onTeam(String name) throws PlayerNotFoundException
    {
        for(Player p : players)
        {
            if(p.getName().equals(name) == false)
            {
                throw new PlayerNotFoundException("No player with that name. ");
            }
            else if(p.getName().equals(name) == true)
            {
                System.out.println(p.getName() + "---" + p.getTeam());
            }
            else
            {
                return false;
            }
        }
    }
}
