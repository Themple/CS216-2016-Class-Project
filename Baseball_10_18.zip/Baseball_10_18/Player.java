
/**
 * This is the basic class that describes each player. 
 * It contains the general stats that all players, 
 * reguardless of position, have. It also contains the 
 * act method for batting. 
 */
public class Player implements Actor
{
    private String name; //The player's name.
    private double battingAverage;//Player's batting average
    private String position; //Position in the team.
    private String fieldPosition;//Player's position for when they are in the field
    private double catchingAverage;//Player's catching average
    private boolean inField;//Boolean for if the player is in the field or not
    
    public Player(String name, String position,double battingAvg,double catchingAvg)
    {
        this.name= name; 
        this.position=position;
        fieldPosition=position;
        battingAverage=battingAvg;
        catchingAverage=catchingAvg;
        inField=true;
    }
    
    public String getName() //Returns the Player's name.
    {
        return name; 
    }
    
    public String getPosition() //Returns the Player's Position (or Role) in the team.
    {
        return position;
    }
    
    public void setPosition(String p)
    {
        position=p;
    }
    
    /*
     * Sets the player's position to the bench as if the player got out
     */
    public void out()
    {
        position="bench";
    }
    
    /*
     * Changes the players position to either their field position or bench depending on if they are to be put in the field or not
     */
    public void setInField(Boolean a)
    {
        inField=a;
        if(inField)
        {
            position=fieldPosition;
        }
        else
        {
            position="bench";
        }
    }
    
    /*
     * Sets the player to be at bat
     */
    public void atBat()
    {
        position="batting";
    }
    
    /*
     * Changes the player's position as if they are switching sides
     */
    public void switchSides()
    {
        if(inField)
        {
            inField=false;
            position="bench";
        }
        else
        {
            inField=true;
            position=fieldPosition;
        }
    }
    
    /*
     * Sets the player's position to the bench
     */
    public void bench()
    {
        position="bench";
    }
    
    /*
     * returns if the player is in the field or not
     */
    public boolean isInField()
    {
        return inField;
    }
    
    /*
     * Makes the player act in a certain manner depending on their current position
     */
    public void act() 
    {
        if(position.equals("batting"))
        {
            double chance=Math.random();
            int direction=(int)(Math.random()*3)+1;
            if(chance<=battingAverage)
            {
                if(chance<=.1*battingAverage)
                {
                    //he hit a homerun
                    System.out.print("player hit a homerun ");
                    if(direction==1)
                    {
                        System.out.println("to left field");
                    }
                    else if(direction==2)
                    {
                        System.out.println("to mid field");
                    }
                    else if(direction==3)
                    {
                        System.out.println("to right field");
                    }
                    position="bench";
                }
                else if(chance<=.3*battingAverage)
                {
                    //he hit a triple
                    System.out.print("player hit a triple ");
                    if(direction==1)
                    {
                        System.out.println("to left field");
                    }
                    else if(direction==2)
                    {
                        System.out.println("to mid field");
                    }
                    else if(direction==3)
                    {
                        System.out.println("to right field");
                    }
                    position="third";
                }
                else if(chance<=.5*battingAverage)
                {
                    //he hit a double
                    System.out.print("player hit a double ");
                    if(direction==1)
                    {
                        System.out.println("to left field");
                    }
                    else if(direction==2)
                    {
                        System.out.println("to mid field");
                    }
                    else if(direction==3)
                    {
                        System.out.println("to right field");
                    }
                    position="second";
                }
                else
                {
                    //he hit a single
                    System.out.print("player hit a single ");
                    if(direction==1)
                    {
                        System.out.println("to left field");
                    }
                    else if(direction==2)
                    {
                        System.out.println("to mid field");
                    }
                    else if(direction==3)
                    {
                        System.out.println("to right field");
                    }
                    position="first";
                }
            }
            else if(chance<battingAverage*.1+battingAverage)
            {
                //he hit a foul
                System.out.println("player hit a foul");
            }
            else
            {
                //he got a strike
                System.out.println("player hit a strike");
            }
        }
        else if((position.equals("leftField"))||(position.equals("midField"))||(position.equals("rightField")))
        {
            double chance= Math.random();
            if(chance<= catchingAverage)
            {
                //catches ball, throw it to a given base.
                System.out.println("caught ball");
            }
            else  
            {
                //didnt catch the ball
                 System.out.println("dropped the ball");
            }
        }
        else if((position.equals("first"))||(position.equals("second"))||(position.equals("third")))
        {
            double chance=Math.random();
            if(chance<=.8)
            {
                //Player made it to the next base
                if(position.equals("first"))
                {
                    position="second";
                }
                else if(position.equals("second"))
                {
                    position="third";
                }
                else if(position.equals("third"))
                {
                    position="bench";
                    //send message for the player going to home base
                }
            }
        }
    }
}
