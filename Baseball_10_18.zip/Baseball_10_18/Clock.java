
/**
 * Write a description of class Clock here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Clock
{
    // instance variables - replace the example below with your own
    private int tb;
    private int inning;
    private int hour;
    private int minute;
    private boolean playing;

    /**
     * Constructor for objects of class Clock
     */
    public Clock()
    {
        // initialise instance variables
        tb=1;
        inning=1;
        hour=0;
        minute=0;
        playing=false;
    }
    
    public void changeInning()
    {
        if(tb==1)
        {
            tb=2;
        }
        else
        {
            inning=inning++;
            tb=1;
        }
    }
    
    public void startGame()
    {
        playing=false;
    }
    
    public void tick()
    {
        while(playing=true)
        {
            minute=minute+1;
            if(minute==60)
            {
                hour=hour+1;
                minute=0;
            }
            System.out.println(getHour()+ ":"+ getMinute());
                        try {
             Thread.sleep(1000);
            } catch(InterruptedException ex) {
             Thread.currentThread().interrupt();
             }
        }
        
    }
    
    public int getHour()
    {
        return hour;
    }
    
    public int getMinute()
    {
        return minute;
    }

}
