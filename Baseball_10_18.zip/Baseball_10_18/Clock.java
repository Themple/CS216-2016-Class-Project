
/**
 * Write a description of class Clock here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Clock
{
    // instance variables - replace the example below with your own
    private int tb;
    private int inning;
    private int hour;
    private int minute;
    private boolean playing;

    /**
     * Constructor for objects of class Clock
     */
    public Clock()
    {
        // initialise instance variables
        tb=1;
        inning=1;
        hour=0;
        minute=0;
        playing=false;
    }
    
    public void changeInning()
    {
        if(tb==1)
        {
            tb=2;
        }
        else
        {
            inning=inning+1;
            tb=1;
        }
    }
    
    public void startGame()
    {
        playing=false;
    }
    
    public void tick()
    {
         minute=minute+1;
         if(minute==60)
         {
             hour=hour+1;
             minute=0;
         }
        
    }
    
    public String getTime()
    {
        if(minute<10)
        {
            return getHour()+ ":0"+ getMinute();
        }
        return getHour()+ ":"+ getMinute();
    }
    
    public int getHour()
    {
        return hour;
    }
    
    public int getMinute()
    {
        return minute;
    }
    
    public String getInning()
    {
        if(tb==1)
        {
            return "top of the "+ inning;
        }
        else{
            return "bottom of the " + inning;
        }
    }
}
