import java.util.ArrayList;
/**
 * Write a description of class Event here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class EventMessage
{
    private Player p;
    private int time;
    private int messageCode;
    private int additional;
    private ArrayList <EventMessage> m;
    
    public EventMessage (Player p, int time, int messageCode, int additional)
    {
        m = new ArrayList<>();
    }

    public void addEvent( Player p, int time, int messageCode, int additional)
    {
       m.add(new EventMessage( p, time, messageCode, additional));
    }

      
    }
    
    
    
    
