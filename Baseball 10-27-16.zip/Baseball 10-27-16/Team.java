import java.util.ArrayList;
/**
 * Team class will create and maintain the two teams that are playing. 
 * 
 * @author Josh Martine
 */
public class Team
{
    private ArrayList<Player> players;
    private ArrayList<Player> teamOne, teamTwo;
    private String teamOneName, teamTwoName;
    private boolean teamOneAtBat, teamTwoAtBat;
    private Clock clock;
    private Randomizer rand;
    private Stat stat;

    public Team(String teamOneName, String teamTwoName, Clock clock, Randomizer rand, Stat stat){
        this.teamOneName = teamOneName;
        this.teamTwoName = teamTwoName;
        this.clock = clock;
        this.rand = rand;
        this.stat = stat;
        players = new ArrayList<>();
        teamOne = new ArrayList<>();
        teamTwo = new ArrayList<>();
        firstAtBat();
    }
    
    /**
     * determines the team that will bat first
     */
    
    private void firstAtBat(){
        if(rand.randomize(1)+1 == 2) teamOneAtBat = true;
        else teamTwoAtBat = true;
    }

    /**
     * called from controller. adds players to the teams.
     */
    
    public void setTeams(ArrayList<Player> teams){
        for(int i = 0; i < teams.size() / 2; i++){
            teamOne.add(teams.get(i));
        }

        for(int i = teams.size() / 2; i < teams.size(); i++){
            teamTwo.add(teams.get(i));
        }	
    }

    /**
     * returns an arraylist of players in the specified team. if the team is invalid, throws an exception rather
     * than returning null
     */
    public ArrayList<Player> getTeam(String teamName){
        if(teamName.equals(teamOneName)) return teamOne;
        else if(teamName.equals(teamTwoName)) return teamTwo;
        return null;
    }

    /**
     * Returns a player at a given position.
     */

    public Player getPlayer(String playerPos) throws PlayerNotFoundException {
        for(int i = 0; i < teamOne.size(); i++){
            if(teamOne.get(i).getPosition().equals(playerPos)){
                return teamOne.get(i);
            }
        }

        for(int i = 0; i < teamTwo.size(); i++){
            if(teamTwo.get(i).getPosition().equals(playerPos)){
                return teamTwo.get(i);
            }
        }

        throw new PlayerNotFoundException("Player not found at " + playerPos);
    }

    public Player getPlayerByName(String playerName) throws PlayerNotFoundException{

        for(int i = 0; i < teamOne.size(); i++){
            if(teamOne.get(i).getName().equals(playerName)){
                return teamOne.get(i);
            }
        }

        for(int i = 0; i < teamTwo.size(); i++){
            if(teamTwo.get(i).getName().equals(playerName)){
                return teamTwo.get(i);
            }
        }
        throw new PlayerNotFoundException("Player not found: " + playerName);
    }

    /**
     * returns the position of a player. could throw exception if the player position can't be found.
     */

    public String getPlayerPos(Player p) {
        for(int i = 0; i < teamOne.size(); i++){
            if(teamOne.get(i).equals(p)){
                return teamOne.get(i).getPosition();
            }
        }

        for(int i = 0; i < teamTwo.size(); i++){
            if(teamTwo.get(i).equals(p)){
                return teamTwo.get(i).getPosition();

            } 
        }
        return "no position";
    }

    public void changeAtBat(){
        teamOneAtBat = !teamOneAtBat;
        teamTwoAtBat = !teamTwoAtBat;
    }

    public String toString(){
        String retStr = "";
        retStr += teamOneName + ": ";
        for(int i = 0; i < teamOne.size(); i++){
            retStr += teamOne.get(i) + " ";
        }
        retStr += "\n" + teamTwoName + ": ";
        for(int i = 0; i < teamTwo.size(); i++){
            retStr += teamTwo.get(i) + " ";
        }
        return retStr;
    }
}
