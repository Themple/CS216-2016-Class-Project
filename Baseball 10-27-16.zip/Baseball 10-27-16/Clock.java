
/**
 * A custom clock that initiates a "tick" 
 * It is the time variable for the simulation.
 */
public class Clock
{
    private int tb;
    private int inning;
    private int tick;
    private boolean playing;

    /**
     * Constructor for objects of class Clock
     */
    public Clock()
    {
        tb=1;
        inning=1;
        tick=0;
        playing=false;
    }
    
    /**
     * Changes the innings. 
     */
    public void changeInning()
    {
        if(tb==1)
        {
            tb=2;
        }
        else
        {
            inning=inning+1;
            tb=1;
        }
    }
    
    /**
     * Starts the game and resets the clock.
     */
    public void startGame()
    {
        playing=true;
        tb=1;
        inning=1;
        tick=0;
    }
    
    /**
     * Initiates the "tick"; 
     * Controls the time for the simulation.
     */
    public void tick()
    {
         tick=tick+1;
    }
    
    /**
     * Accessor Method for the time variable.
     */
    public int getTime()
    {
       return tick;
    }
    
    /**
     * Returns the inning and the 
     * speific phase of the inning.
     */
    public String getInning()
    {
        if(tb==1)
        {
            return "top of the "+ inning;
        }
        else{
            return "bottom of the " + inning;
        }
    }
}
