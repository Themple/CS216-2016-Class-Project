import java.util.Scanner;
/**
 * Handles the PlayerNotFound exception,
 * depending on how it is involved.
 */
public class PlayerExceptionHandler
{
    /**
     * handles an exception thrown when 
     * trying to put a player on a team.
     */
    public static void main()
    {
        
        try
        {
            if(onTeam(Player.getName()))
            {
                System.out.println("player is on team ___.");
            }
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
    }

    /**
     * Handles an exception thrown when tying
     * to find a player on a team by name.
     */
    public static boolean onTeam(String name) throws PlayerNotFoundException
    {
        for(Player p : players)
        {
            if(p.getName().equals(name) == false)
            {
                throw new PlayerNotFoundException("No player with that name. ");
            }
            else if(p.getName().equals(name) == true)
            {
                System.out.println(p.getName() + "---" + p.getTeam());
            }
            else
            {
                return false;
            }
        }
    }
}
