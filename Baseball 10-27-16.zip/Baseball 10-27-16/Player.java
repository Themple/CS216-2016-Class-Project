
/**
 * This is the basic class that describes each player. 
 * It contains the general stats that all players, 
 * reguardless of position, have. It also contains the 
 * act method for batting. 
 */
public class Player implements Actor
{
    private String name; //The player's name.
    private double battingAverage;//Player's batting average
    private String position; //Position in the team.
    private String fieldPosition;//Player's position for when they are in the field
    private double catchingAverage;//Player's catching average
    private boolean inField;//Boolean for if the player is in the field or not
    private Clock clock;
    private Randomizer rand;
    private static int ballPosition=0;
    private Stat stat;
    public Player(String name, String Fieldposition,double battingAvg,double catchingAvg,Clock c,Randomizer r,Stat s)
    {
        this.name= name; 
        this.position=Fieldposition;
        fieldPosition=Fieldposition;
        battingAverage=battingAvg;
        catchingAverage=catchingAvg;
        inField=true;
        clock=c;
        rand=r;
        stat=s;
    }
    /**
     * Accessor Method for the name variable.
     */
    public String getName()
    {
        return name; 
    }
    /**
     * Accessor method for the position variable.
     */
    public String getPosition()
    {
        return position;
    }
    /**
     * Mutator method for the position variable.
     */
    public void setPosition(String p)
    {
        position=p;
    }
    /**
     * Sets the player's position to the bench as if the player got out
     **/
    public void out()
    {
        position="bench";
    }
    /**
     * Changes the players position to either their field position or bench depending on if they are to be put in the field or not
     **/
    public void setInField(boolean a)
    {
        inField=a;
        if(inField)
        {
            position=fieldPosition;
        }
        else
        {
            position="bench";
        }
    }
    /**
     * Sets the player to be at bat
     **/
    public void atBat()
    {
        position="batting";
    }
    /**
     * Changes the player's position as if they are switching sides
     **/
    public void switchSides()
    {
        if(inField)
        {
            inField=false;
            position="bench";
        }
        else
        {
            inField=true;
            position=fieldPosition;
        }
    }
    /**
     * Sets the player's position to the bench
     **/
    public void bench()
    {
        position="bench";
    }
    /**
     * returns if the player is in the field or not
     **/
    public boolean isInField()
    {
        return inField;
    }
    public int getBallPosition()
    {
        return ballPosition;
    }
    /**
     * Makes the player act in a certain manner depending on their current position
     **/
    public void act() 
    {
        if(position.equals("batting"))
        {
            double chance=rand.randomize(100);
            int direction=rand.randomize(3);
            if(chance<=battingAverage*100)
            {
                if(chance<=10*battingAverage)
                {
                    //he hit a homerun
                    System.out.print("player hit a homerun ");
                    if(direction==1)
                    {
                        System.out.println("to left field");
                        stat.sendEventMessage(this,clock.getTime(),1,1);
                    }
                    else if(direction==2)
                    {
                        System.out.println("to mid field");
                        stat.sendEventMessage(this,clock.getTime(),1,2);
                    }
                    else if(direction==3)
                    {
                        System.out.println("to right field");
                        stat.sendEventMessage(this,clock.getTime(),1,3);
                    }
                    position="bench";
                }
                else if(chance<=30*battingAverage)
                {
                    //he hit a triple
                    System.out.print("player hit a triple ");
                    if(direction==1)
                    {
                        System.out.println("to left field");
                        stat.sendEventMessage(this,clock.getTime(),2,1);
                    }
                    else if(direction==2)
                    {
                        System.out.println("to mid field");
                        stat.sendEventMessage(this,clock.getTime(),2,2);
                    }
                    else if(direction==3)
                    {
                        System.out.println("to right field");
                        stat.sendEventMessage(this,clock.getTime(),2,3);
                    }
                    position="third";
                }
                else if(chance<=50*battingAverage)
                {
                    //he hit a double
                    System.out.print("player hit a double ");
                    if(direction==1)
                    {
                        System.out.println("to left field");
                        stat.sendEventMessage(this,clock.getTime(),3,1);
                    }
                    else if(direction==2)
                    {
                        System.out.println("to mid field");
                        stat.sendEventMessage(this,clock.getTime(),3,2);
                    }
                    else if(direction==3)
                    {
                        System.out.println("to right field");
                        stat.sendEventMessage(this,clock.getTime(),3,3);
                    }
                    position="second";
                }
                else
                {
                    //he hit a single
                    System.out.print("player hit a single ");
                    if(direction==1)
                    {
                        System.out.println("to left field");
                        stat.sendEventMessage(this,clock.getTime(),4,1);
                    }
                    else if(direction==2)
                    {
                        System.out.println("to mid field");
                        stat.sendEventMessage(this,clock.getTime(),4,2);
                    }
                    else if(direction==3)
                    {
                        System.out.println("to right field");
                        stat.sendEventMessage(this,clock.getTime(),4,3);
                    }
                    position="first";
                }
                ballPosition=direction;
            }
            else if(chance<battingAverage*10+battingAverage)
            {
                //he hit a foul
                System.out.println("player hit a foul");
                stat.sendEventMessage(this,clock.getTime(),0,0);
            }
            else
            {
                //he got a strike
                System.out.println("player hit a strike");
                stat.sendEventMessage(this,clock.getTime(),-1,0);
            }
        }
        else if(((position.equals("Left Field"))&&(ballPosition==1))||(position.equals("Mid Field")&&(ballPosition==2))||(position.equals("Right Field")&&(ballPosition==3)))
        {
            double chance=rand.randomize(100);
            if(chance<= catchingAverage*100)
            {
                //catches ball, throw it to a given base.
                System.out.println("caught ball");
                stat.sendEventMessage(this,clock.getTime(),5,0);
            }
            else  
            {
                //didnt catch the ball
                 System.out.println("dropped the ball");
                 stat.sendEventMessage(this,clock.getTime(),6,0);
            }
        }
        else if((position.equals("first"))||(position.equals("second"))||(position.equals("third")))
        {
            double chance=rand.randomize(100);
            if(chance<=80)
            {
                //Player made it to the next base
                if(position.equals("first"))
                {
                        position="second";
                        stat.sendEventMessage(this,clock.getTime(),7,2);
                }
                else if(position.equals("second"))
                {
                    position="third";
                    stat.sendEventMessage(this,clock.getTime(),7,3);
                }
                else if(position.equals("third"))
                {
                    position="bench";
                    stat.sendEventMessage(this,clock.getTime(),8,0);
                    //send message for the player going to home base
                }
            }
            else
            {
                System.out.println("Player got out while running");
                position="bench";
                //send message for getting out
            }
            
        }
    }
    /**
     * Returns the payer's name and position in a string.
     */
    public String toString()
    {
        return name+": "+position;
    }
}
