import java.util.ArrayList;
import java.util.Random;
import java.util.*;
/**
 * Write a description of class Controller here.
 * 
 * @author (Dimitri Terenik) 
 * @version (10/18/16)
 */
public class Controller
{

    ArrayList<Player> plays;
    private Clock clock;
    private ArrayList<Player> players;
    private Stat stat;
    private Randomizer rand;
    private Team team;
    
    public  Controller(){
        plays = new ArrayList<>();
        clock = new Clock();
        team = new Team("red","blue");
        buildPlayer();
        stat = new Stat(team,clock);
        rand = new Randomizer();

    }
    
    public void buildPlayer() 
    {
        plays.add(new Player("Alfredo Aceves","Pitcher" , .200, .511,clock,rand,team)); //1 
        plays.add(new Player("Brandon Bantz","Catcher" , .245, .571,clock,rand,team)); //2 
        plays.add(new Player("Miguel Cabrera","First Base" , .316, .641,clock,rand,team)); //3 
        plays.add(new Player("Dustin Pedroia","Secound Base" , .318, .671,clock,rand,team)); //4 
        plays.add(new Player("David Adams","Third Base" , .193, .441,clock,rand,team)); //5 
        plays.add(new Player("Nick Ahmed","Short Stop" , .218, .481,clock,rand,team)); //6 
        plays.add(new Player("Abraham Almonte","Left Field" , .264, .661,clock,rand,team)); //7 
        plays.add(new Player("Mike Trout","Center Field" , .315, .811,clock,rand,team)); //8 
        plays.add(new Player("Pedro Valdes","Right Field" , .247, .731,clock,rand,team)); //9 
        plays.add(new Player("Mike Adams","Pitcher" , .175, .341,clock,rand,team)); //10 
        plays.add(new Player("Carson Blair","Catcher" , .250, .441,clock,rand,team)); //11 
        plays.add(new Player("Brandon Allen","First Base" , .100, .681,clock,rand,team)); //12 
        plays.add(new Player("Jose Pirela","Second Base" , .154, .581,clock,rand,team)); //13 
        plays.add(new Player("Kris Bryant","Third Base" , .292, .681,clock,rand,team)); //14
        plays.add(new Player("Gavin Cecchini","Short Stop" , .333, .345,clock,rand,team)); //15
        plays.add(new Player("Tyler Colvin","Left Field" , .233, .654,clock,rand,team)); //16 
        plays.add(new Player("Dalton Pompey","Center Field" , .222, .475,clock,rand,team)); //17 
        plays.add(new Player("Adam Walker","Right Field" , .243, .657,clock,rand,team)); //18 
    }
    
    public void play(){
        for(int j = 0; j<=500;j++){

            for (Player p: plays){
                p.act();
            }
            clock.tick();  
        }
    }
}
