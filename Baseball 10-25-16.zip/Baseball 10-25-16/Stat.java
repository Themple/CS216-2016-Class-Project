import java.util.ArrayList;
/**
 * For now, This is going to recieve the event messages 
 * sent in by each specific class. 
 * Stat will also display each message. 
 * 
 * -Ryan Priore, building dummy.
 */
public class Stat extends EventMessage
{
    private Player p; 
    private int time;
    private int messageCode; 
    private int additional;
    public Stat(Player p, int time, int messageCode, int additional)
    {
      super(p, time, messageCode, additional);
      
    }
    /**
     * calls the parent class method to build the arraylist. 
     * This way we can work from the same list... in theory.
     */
    public void addEvent(Player p, int time, int messageCode, int additional)
    {
        m.add(new EventMessage(p, time, messageCode, additional));
    }
    /**
     * This is dummy code to print events. 
     * It will change when every class can send a message. 
     * For now, this should work for players. 
     */
    public void printEventMessage() 
    {
        for(EventMessage x: m) 
        {
            System.out.println(x.toString());
        }
    }
}
