
/**
 * Actor interface that provides an act method
 * for all subclasses to inherit and override. 
 */

    public interface Actor
    {
        public void act();
        
    }
    
    

