import java.util.ArrayList;
import java.util.Random;
/**
 * Grand loop of the project.
 */
public class Controller
{
    ArrayList<Player> plays;
    Team t, t2;
    Clock clock = new Clock();
    public void play(){
        for(int j = 0; j<=500;j++){
            //team 1 maybe second for second team.
            for (Player p: plays){
                p.act();
            }
            clock.tick();  
        }
    }
}
